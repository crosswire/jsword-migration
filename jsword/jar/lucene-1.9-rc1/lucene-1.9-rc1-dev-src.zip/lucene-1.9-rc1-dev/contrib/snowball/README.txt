Lucene Snowball README file

$Id: README.txt 150870 2002-12-23 22:50:28Z cutting $

INTRODUCTION

This project provides pre-compiled version of the Snowball stemmers
together with classes integrating them with the Lucene search engine.

More documentation is provided in the 'docs' subdirectory.

For more information on Lucene, see:
  http://jakarta.apache.org/lucene

For more information on Snowball, see:
  http://snowball.tartarus.org/

