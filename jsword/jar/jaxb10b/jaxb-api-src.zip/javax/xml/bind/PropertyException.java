/*
 * $Id: PropertyException.java,v 1.3 2002/08/14 21:17:15 ryans Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.xml.bind;



/**
 * This exception indicates that an error was encountered while getting or
 * setting a property.
 * 
 * @author <ul><li>Ryan Shoemaker, Sun Microsystems, Inc.</li><li>Kohsuke Kawaguchi, Sun Microsystems, Inc.</li><li>Joe Fialli, Sun Microsystems, Inc.</li></ul>
 * @version $Revision: 1.3 $ $Date: 2002/08/14 21:17:15 $
 * @see JAXBContext
 * @see Validator
 * @see Unmarshaller
 * @since JAXB1.0
 */
public class PropertyException extends JAXBException {

	/**
	 * Constructor for PropertyException.
	 * @param message
	 */
	public PropertyException(String message) {
		super(message);
	}

	/**
	 * Constructor for PropertyException.
	 * @param message
	 * @param errorCode
	 */
	public PropertyException(String message, String errorCode) {
		super(message, errorCode);
	}

	/**
	 * Constructor for PropertyException.
	 * @param exception
	 */
	public PropertyException(Throwable exception) {
		super(exception);
	}

	/**
	 * Constructor for PropertyException.
	 * @param message
	 * @param exception
	 */
	public PropertyException(String message, Throwable exception) {
		super(message, exception);
	}

	/**
	 * Constructor for PropertyException.
	 * @param message
	 * @param errorCode
	 * @param exception
	 */
	public PropertyException(
		String message,
		String errorCode,
		Throwable exception) {
		super(message, errorCode, exception);
	}

	/**
	 * Constructor for PropertyException.
	 * @param name the name of the property related to this exception
	 * @param value the value of the property related to this exception
	 */
	public PropertyException(String name, Object value) {
		super( Messages.format( Messages.NAME_VALUE, 
                                        name, 
                                        value.toString() ) );
	}


}
