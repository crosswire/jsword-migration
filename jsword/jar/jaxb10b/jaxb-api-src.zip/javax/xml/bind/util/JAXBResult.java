/*
 * @(#)$Id: JAXBResult.java,v 1.1 2002/08/09 20:11:34 kk122374 Exp $
 *
 * Copyright 2002 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package javax.xml.bind.util;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.UnmarshallerHandler;
import javax.xml.transform.Result;
import javax.xml.transform.sax.SAXResult;

/**
 * JAXP {@link Result} implementation
 * that unmarshals a JAXB object.
 * 
 * <p>
 * The user shouldn't call the methods defined
 * in the {@link SAXResult} class.
 * 
 * @author
 * 	Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class JAXBResult extends SAXResult {

    /**
     * Creates a new instance that uses the specified
     * JAXBContext to unmarshal.
     * 
     * @exception JAXBException
     *      If it fails to create a new unmarshaller from
     *      the specified JAXBContext.
     */
    public JAXBResult( JAXBContext context ) throws JAXBException {
        this(context.createUnmarshaller());
    }
    
    /**
     * Creates a new instance that uses the specified
     * Unmarshaler to unmarshal an object.
     * 
     * <p>
     * This JAXBResult object will use the specified Unmarshaller
     * instance. It is the caller's responsibility not to use the
     * same Unmarshaller for other purposes while it is being
     * used by this object.
     * 
     * <p>
     * The primary purpose of this method is to allow the client
     * to configure Unmarshaller. Unless you know what you are doing,
     * it's easier and safer to pass a JAXBContext.
     */
    public JAXBResult( Unmarshaller _unmarshaller ) {
        this.unmarshallerHandler = _unmarshaller.getUnmarshallerHandler();
        
        super.setHandler(unmarshallerHandler);
    }
    
    /**
     * Unmarshaller that will be used to unmarshal
     * the input documents.
     */
    private final UnmarshallerHandler unmarshallerHandler;

    /**
     * Gets the unmarshalled object created by the transformation.
     * 
     * @return
     *      Always return a non-null object.
     * 
     * @exception JAXBException
     *      If unmarshalling fails.
     */
    public Object getResult() throws JAXBException {
        return unmarshallerHandler.getResult();
    }
}
