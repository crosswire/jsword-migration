/*
 * $Id: ValidationEventImpl.java,v 1.3 2002/04/17 19:34:13 ryans Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package javax.xml.bind.helpers;

import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventLocator;

/**
 * Default implementation of the ValidationEvent interface.
 * 
 * <p>
 * JAXB providers are allowed to use whatever class that implements
 * the ValidationEvent interface. This class is just provided for a
 * convenience.
 *
 * @author <ul><li>Kohsuke Kawaguchi, Sun Microsystems, Inc.</li></ul> 
 * @version $Revision: 1.3 $
 * @see javax.xml.bind.Validator
 * @see javax.xml.bind.ValidationEventHandler
 * @see javax.xml.bind.ValidationEvent
 * @see javax.xml.bind.ValidationEventLocator
 * @since JAXB1.0
 */
public class ValidationEventImpl implements ValidationEvent
{
    public ValidationEventImpl( int _severity,
        String _message, ValidationEventLocator _locator ) {
        
        this(_severity,_message,_locator,null);
    }

    public ValidationEventImpl( int _severity,
        String _message, ValidationEventLocator _locator,
        Throwable _linkedException ) {
        
        this.severity = _severity;
        this.message = _message;
        this.locator = _locator;
        this.linkedException = _linkedException;
    }
    
    private int severity;
    private String message;
    private Throwable linkedException;
    private ValidationEventLocator locator;
    
    public int getSeverity() {
        return severity;
    }
    public void setSeverity( int _severity ) {
        this.severity = _severity;
    }
    
    public String getMessage() {
        return message;
    }
    public void setMessage( String _message ) {
        this.message = _message;
    }
    
    public Throwable getLinkedException() {
        return linkedException;
    }
    public void setLinkedException( Throwable _linkedException ) {
        this.linkedException = _linkedException;
    }
    
    public ValidationEventLocator getLocator() {
        return locator;
    }
    public void setLocator( ValidationEventLocator _locator ) {
        this.locator = _locator;
    }
}
