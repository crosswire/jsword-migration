/*
 * $Id: NotIdentifiableEventImpl.java,v 1.1 2002/09/04 17:45:07 ryans Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.xml.bind.helpers;

import javax.xml.bind.ValidationEventLocator;

/**
 * Default implementation of the NotIdentifiableEvent interface.
 * 
 * <p>
 * JAXB providers are allowed to use whatever class that implements
 * the ValidationEvent interface. This class is just provided for a
 * convenience.
 *
 * @author <ul><li>Ryan Shoemaker, Sun Microsystems, Inc.</li></ul> 
 * @version $Revision: 1.1 $
 * @see javax.xml.bind.NotIdentifiableEvent
 * @see javax.xml.bind.Validator
 * @see javax.xml.bind.ValidationEventHandler
 * @see javax.xml.bind.ValidationEvent
 * @see javax.xml.bind.ValidationEventLocator
 * @since JAXB1.0
 */
public class NotIdentifiableEventImpl
    extends ValidationEventImpl
    implements javax.xml.bind.NotIdentifiableEvent {

    /**
     * Constructor for NotIdentifiableEvent.
     * @param _severity
     * @param _message
     * @param _locator
     */
    public NotIdentifiableEventImpl(
        int _severity,
        String _message,
        ValidationEventLocator _locator) {
        super(_severity, _message, _locator);
    }

    /**
     * Constructor for NotIdentifiableEvent.
     * @param _severity
     * @param _message
     * @param _locator
     * @param _linkedException
     */
    public NotIdentifiableEventImpl(
        int _severity,
        String _message,
        ValidationEventLocator _locator,
        Throwable _linkedException) {
        super(_severity, _message, _locator, _linkedException);
    }

}
