/*
 * $Id: ValidationEventLocatorImpl.java,v 1.7 2002/05/07 14:43:56 ryans Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package javax.xml.bind.helpers;

import java.net.URL;
import java.net.MalformedURLException;
import javax.xml.bind.ValidationEventLocator;
import org.w3c.dom.Node;
import org.xml.sax.Locator;
import org.xml.sax.SAXParseException;

/**
 * Default implementation of the ValidationEventLocator interface.
 * 
 * <p>
 * JAXB providers are allowed to use whatever class that implements
 * the ValidationEventLocator interface. This class is just provided for a
 * convenience.
 *
 * @author <ul><li>Kohsuke Kawaguchi, Sun Microsystems, Inc.</li></ul> 
 * @version $Revision: 1.7 $
 * @see javax.xml.bind.Validator
 * @see javax.xml.bind.ValidationEventHandler
 * @see javax.xml.bind.ValidationEvent
 * @see javax.xml.bind.ValidationEventLocator
 * @since JAXB1.0
 */
public class ValidationEventLocatorImpl implements ValidationEventLocator
{
    public ValidationEventLocatorImpl() {
    }
    /** Constructs an object from an org.xml.sax.Locator. */
    public ValidationEventLocatorImpl( Locator loc ) {
        this.url = toURL(loc.getSystemId());
        this.columnNumber = loc.getColumnNumber();
        this.lineNumber = loc.getLineNumber();
    }
    /** Constructs an object from the location information of a SAXParseException. */
    public ValidationEventLocatorImpl( SAXParseException e ) {
        this.url = toURL(e.getSystemId());
        this.columnNumber = e.getColumnNumber();
        this.lineNumber = e.getLineNumber();
    }
    /** Constructs an object that points to a DOM Node. */
    public ValidationEventLocatorImpl(Node _node) {
        this.node = _node;
    }
    /** Constructs an object that points to a JAXB content object. */
    public ValidationEventLocatorImpl(Object _object) {
        this.object = _object;
    }
    
    /** Converts a system ID to an URL object. */
    private static URL toURL( String systemId ) {
        try {
            return new URL(systemId);
        } catch( MalformedURLException e ) {
            // TODO: how should we handle system id here?
            return null;    // for now
        }
    }
    
    private URL url = null;
    private int offset = -1;
    private int lineNumber = -1;
    private int columnNumber = -1;
    private Object object = null;
    private Node node = null;
    
    public URL getURL() {
        return url;
    }    
    public void setURL( URL _url ) {
        this.url = _url;
    }    
    
    public int getOffset() {
        return offset;
    }
    public void setOffset( int _offset ) {
        this.offset = _offset;
    }
    
    public int getLineNumber() {
        return lineNumber;
    }
    public void setLineNumber( int _lineNumber ) {
        this.lineNumber = _lineNumber;
    }
    
    public int getColumnNumber() {
        return columnNumber;
    }
    public void setColumnNumber( int _columnNumber ) {
        this.columnNumber = _columnNumber;
    }
    
    public Object getObject() {
        return object;
    }
    public void setObject( Object _object ) {
        this.object = _object;
    }
    
    public Node getNode() {
        return node;
    }
    public void setNode( Node _node ) {
        this.node = _node;
    }
    
}
