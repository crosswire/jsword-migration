/*
 * @(#)$Id: AbstractMarshallerImpl.java,v 1.12 2002/09/04 15:26:24 ryans Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package javax.xml.bind.helpers;

import javax.xml.bind.Marshaller;
import javax.xml.bind.JAXBException;
import javax.xml.bind.PropertyException;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.dom.DOMResult;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
// J2SE1.4 feature
// import java.nio.charset.Charset;
// import java.nio.charset.UnsupportedCharsetException;

/**
 * Partial default <tt>Marshaller</tt> implementation.
 * 
 * <p>
 * This class provides a partial default implementation for the
 * {@link javax.xml.bind.Marshaller} interface.
 * 
 * <p>
 * The only method that a JAXB Provider has to implement is
 * {@link Marshaller#marshal(Object, Result) marshal(Object, javax.xml.transform.Result)}.
 *
 * @author <ul><li>Kohsuke Kawaguchi, Sun Microsystems, Inc.</li></ul>
 * @version $Revision: 1.12 $ $Date: 2002/09/04 15:26:24 $
 * @see javax.xml.bind.Marshaller
 * @since JAXB1.0
 */
public abstract class AbstractMarshallerImpl implements Marshaller
{
    /** handler that will be used to process errors and warnings during marshal */
    private ValidationEventHandler eventHandler = 
        new DefaultValidationEventHandler();
    
    //J2SE1.4 feature
    //private Charset encoding = null;
    private String encoding = "UTF-8";
    
    // store the value of the schemaLocation property
    private String schemaLocation = null;

    // store the value of the noNamespaceSchemaLocation property
    private String noNSSchemaLocation = null;
       
    public final void marshal( Object obj, java.io.OutputStream os ) 
        throws JAXBException {
            
        marshal( obj, new StreamResult(os) );
    }
    
    public final void marshal( Object obj, java.io.Writer w ) 
        throws JAXBException {
            
        marshal( obj, new StreamResult(w) );
    }
    
    public final void marshal( Object obj, org.xml.sax.ContentHandler handler ) 
        throws JAXBException {
            
        marshal( obj, new SAXResult(handler) );
    }
    
    public final void marshal( Object obj, org.w3c.dom.Node node ) 
        throws JAXBException {
            
        marshal( obj, new DOMResult(node) );
    }
    
    protected final String getEncoding() {
        return encoding;
    }
    
    protected final void setEncoding( String encoding ) {
        this.encoding = encoding;
    }
    
    protected final String getSchemaLocation() {
        return schemaLocation;
    }
    
    protected final void setSchemaLocation( String location ) {
        schemaLocation = location;
    }
    
    protected final String getNoNSSchemaLocation() {
        return noNSSchemaLocation;
    }
    
    protected final void setNoNSSchemaLocation( String location ) {
        noNSSchemaLocation = location;
    }
    
    
    static String[] aliases = {
        "UTF-8", "UTF8",
        "UTF-16", "Unicode",
        "UTF-16BE", "UnicodeBigUnmarked",
        "UTF-16LE", "UnicodeLittleUnmarked",
        "US-ASCII", "ASCII",
        "TIS-620", "TIS620",
        
        // taken from the project-X parser
        "ISO-10646-UCS-2", "Unicode",
    
        "EBCDIC-CP-US", "cp037",
        "EBCDIC-CP-CA", "cp037",
        "EBCDIC-CP-NL", "cp037",
        "EBCDIC-CP-WT", "cp037",
    
        "EBCDIC-CP-DK", "cp277",
        "EBCDIC-CP-NO", "cp277",
        "EBCDIC-CP-FI", "cp278",
        "EBCDIC-CP-SE", "cp278",
    
        "EBCDIC-CP-IT", "cp280",
        "EBCDIC-CP-ES", "cp284",
        "EBCDIC-CP-GB", "cp285",
        "EBCDIC-CP-FR", "cp297",
    
        "EBCDIC-CP-AR1", "cp420",
        "EBCDIC-CP-HE", "cp424",
        "EBCDIC-CP-BE", "cp500",
        "EBCDIC-CP-CH", "cp500",
    
        "EBCDIC-CP-ROECE", "cp870",
        "EBCDIC-CP-YU", "cp870",
        "EBCDIC-CP-IS", "cp871",
        "EBCDIC-CP-AR2", "cp918",
        
        // IANA also defines two that JDK 1.2 doesn't handle:
        //  EBCDIC-CP-GR        --> CP423
        //  EBCDIC-CP-TR        --> CP905
    };
    
    /**
     * Gets the corresponding Java encoding name from an IANA name.
     * 
     * This method is a helper method for the derived class to convert
     * encoding names.
     * 
     * @exception UnsupportedEncodingException
     *      If this implementation couldn't find the Java encoding name.
     */
    protected String getJavaEncoding( String encoding ) throws UnsupportedEncodingException {
        try {
            "1".getBytes(encoding);
            return encoding;
        } catch( UnsupportedEncodingException e ) {
            // try known alias
            for( int i=0; i<aliases.length; i+=2 ) {
                if(encoding.equals(aliases[i])) {
                    "1".getBytes(aliases[i+1]);
                    return aliases[i+1];
                }
            }
            
            throw new UnsupportedEncodingException(encoding);
        }
        /* J2SE1.4 feature
        try {
            this.encoding = Charset.forName( _encoding );
        } catch( UnsupportedCharsetException uce ) {
            throw new JAXBException( uce );
        }
         */
    }
    
    public void setProperty( String name, Object value )
        throws PropertyException {
        
        throw new PropertyException(name, value);
    }
    
    public Object getProperty( String name )
        throws PropertyException {
                   
        throw new PropertyException(name);
    }
    /**
     * @see javax.xml.bind.Marshaller#getEventHandler()
     */
    public ValidationEventHandler getEventHandler() throws JAXBException {
        return eventHandler;
    }

    /**
     * @see javax.xml.bind.Marshaller#setEventHandler(ValidationEventHandler)
     */
    public void setEventHandler(ValidationEventHandler handler)
        throws JAXBException {
        
        if( handler == null ) {
            eventHandler = new DefaultValidationEventHandler();
        } else {
            eventHandler = handler;
        }
    }

}
