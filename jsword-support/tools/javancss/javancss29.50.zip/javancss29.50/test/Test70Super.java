public class Test70Super
{
    protected int a = 0;
}
