;;
package too;
public class sdf {
public void bug sdf() {
}
}
