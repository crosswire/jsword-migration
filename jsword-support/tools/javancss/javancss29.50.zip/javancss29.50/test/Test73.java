/*
  *
  */
//package funktion;

//import geometrie.LShape;
//import geometrie.Punkt2D;

/**
  * Eine Funktion von zwei Ver�nderlichen
  */
public strictfp interface Test73 {
}
