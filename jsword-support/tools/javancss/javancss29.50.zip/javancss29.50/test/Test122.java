public interface Test123
{ 
    /** Gets one file. */ 
    java.io.File getFile(); 
}
