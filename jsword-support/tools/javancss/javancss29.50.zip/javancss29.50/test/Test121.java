import java.io.File;
import java.util.Set;

public interface Test120
{
   /** Gets some files. */
   Set<File> getFiles();

   /** Gets one file. */
   File getFile();
}
