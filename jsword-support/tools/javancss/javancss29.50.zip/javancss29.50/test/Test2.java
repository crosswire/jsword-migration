package test;

import nothing;

public class Something {
	public Something() {
		super();
	}

	public void sleep();

	public void run() {
		int i = 5;
	}
}
// ncss = 8
