package com.webify.webapp.wlib.palette;

import org.apache.commons.lang.enum.Enum;

/**
 *  Defines different sorting strategies for the {@link Palette}
component.
 *
 *  @author Howard Lewis Ship
 *  @version $Id: Test120.java,v 1.1 2006/06/12 21:37:45 clemens Exp clemens $
 *
 **/
public final class Test120 extends Enum {
}
