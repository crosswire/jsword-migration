* Java2HTML Version 1.5 is a tool that converts a whole bunch of Java Source Code into colourised browsable HTML format.

* Unzip Java2HTML.zip to a temporary directory. Java2HTML.zip contains the following files and directories:- 

Java2HTML.html	Further Instructions on the Installation and use of Java2HTML.
java2html_ant_task.html Instructions on the use of Java2HTML wil Ant.
j2h			Unix Script to wrap the Java2HTML call. Change as required.
j2h.bat			Dos Script to wrap the Java2HTML call. Change as required.
j2h.jar			Java2HTML JAR file, see Java2HTML.html for instructions on use. 
example1.bat		Example1 Script.
example2.bat        Example2 Script.
.\api_examples		Example of Using Java2HTML API.
.\docsapi			JavaDoc for Java2HTML API.
change_history.html Change History
gpl.txt         License 
readme.txt		This File.
