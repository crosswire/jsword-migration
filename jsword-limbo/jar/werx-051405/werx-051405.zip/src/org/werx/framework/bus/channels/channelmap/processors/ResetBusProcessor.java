/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.channelmap.processors;

import java.util.Iterator;
import java.util.Map;

import org.werx.framework.bus.channels.signals.ClearChannel;
import org.werx.framework.commons.interfaces.IProcessor;

/**
 * Clears the bus.
 */
public class ResetBusProcessor implements IProcessor {
    
    private final Map busMap;
    private static final ClearChannel CLEAR=new ClearChannel();
    public ResetBusProcessor(Map busMap)
    {
        this.busMap=busMap;
    }
    /**
     * Clears all cahnnels, clears the map,
     * The resets are to aid in the gc.
     */
    public void doProcess(Object busSignal) {
  
        //  Clear the channels
        Iterator it = busMap.entrySet().iterator();

        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            IProcessor currentChannel = (IProcessor) entry.getValue();
            currentChannel.doProcess(CLEAR);
        }
        
        
        System.gc();

    }

}
