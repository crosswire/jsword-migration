/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus.signals;

/**
 * 
 */

public class ImmutableErrorMessage implements IErrorMessage {

	public static final String OK = "OK";

	public static final String MESSAGE = "No error indicated.";

	/**
	 * returns OK cannot be overriden. Used by BusSignal as standard error
	 * message indicating no problems.
	 */
	public final String getErrorAction() {
		return OK;
	}

	/**
	 * Cannot be overriden and will not set the Action for this. The user must
	 * use the mutable ErrorMessage or a custom message with IErrorMessage
	 * interface.
	 */
	public final void setErrorAction(String msg) {
		//Do nothing...this is not settable
	}

	/**
	 * Cannot be overriden and will not set the ErrorMessage for this. The user
	 * must use the mutable ErrorMessage or a custom message with IErrorMessage
	 * interface.
	 */
	public void setErrorMessage(String msg) {
		//Do nothing...this is not settable.
	}

	/**
	 * Gets the errorMessage attribute of the IErrorMessage
	 *  
	 */
	public String getErrorMessage() {
		return MESSAGE;
	}

	/**
	 * Add attributes to the error message
	 *  
	 */
	public void putValue(Object key, Object value) {
		//Do nothing...not settable
	}

	/**
	 * Get attributes from the error message.
	 *  
	 */
	public Object getValue(Object key) {
		//No valid value to return...
		return null;
	}

}

