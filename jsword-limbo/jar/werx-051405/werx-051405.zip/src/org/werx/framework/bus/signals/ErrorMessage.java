/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus.signals;

import java.util.HashMap;

/**
 * 
 */

public class ErrorMessage implements IErrorMessage {
	private final HashMap mapOfAttributes = new HashMap();

	public ErrorMessage(String action, String msg) {
		mapOfAttributes.put(IErrorMessage.ERROR_ACTION, action);
		mapOfAttributes.put(IErrorMessage.ERROR_MESSAGE, msg);
	}

	/**
	 * Gets the ErrorAction to be used in handling the error.
	 */
	public String getErrorAction() {
		return (String) mapOfAttributes.get(IErrorMessage.ERROR_ACTION);
	}

	/**
	 * Sets the error action to signal to the listener what error has occured.
	 * The user may use this to set up error handling procedures.
	 */
	public void setErrorAction(String msg) {
		mapOfAttributes.put(IErrorMessage.ERROR_ACTION, msg);
	}

	/**
	 * Sets the error message to send back.
	 * 
	 * @return The errorMessage value
	 */
	public void setErrorMessage(String msg) {
		mapOfAttributes.put(IErrorMessage.ERROR_MESSAGE, msg);
	}

	/**
	 * Gets the errorMessage attribute of the IErrorMessage
	 *  
	 */
	public String getErrorMessage() {
		return (String) mapOfAttributes.get(IErrorMessage.ERROR_MESSAGE);
	}

	/**
	 * Add attributes to the error message
	 *  
	 */
	public void putValue(Object key, Object value) {
		mapOfAttributes.put(key, value);
	}

	/**
	 * Get attributes from the error message.
	 *  
	 */
	public Object getValue(Object key) {
		return mapOfAttributes.get(key);
	}
	
	public String toString()
	{
		return mapOfAttributes.toString();
	}

}

