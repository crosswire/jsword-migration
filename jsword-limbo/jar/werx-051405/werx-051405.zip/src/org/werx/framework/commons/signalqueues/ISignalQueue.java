/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.commons.signalqueues;

/**
 * @author Bradlee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface ISignalQueue {
    public abstract void add(Object signal);

    public abstract Object remove();

    public abstract boolean isEmpty();

    public abstract int size();

    public abstract void clear();
}