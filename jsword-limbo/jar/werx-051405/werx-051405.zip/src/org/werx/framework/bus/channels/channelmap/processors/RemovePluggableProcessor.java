/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.channelmap.processors;

import java.lang.reflect.Method;
import java.util.Map;

import org.werx.framework.bus.channels.signals.RemoveChannelListener;
import org.werx.framework.bus.channels.signals.RemovePluggable;
import org.werx.framework.commons.interfaces.IProcessor;

/**
 * @author Bradlee
 *
 * This removes all the methods associated with any given object/instance
 * from the channel map. Since an object can have multiple channels,
 * this procssor runs through them and ensures they are all removed.
 *
 */
public class RemovePluggableProcessor implements IProcessor {
   
        private final String channelPrefix;
        private final Map busMap;
        public RemovePluggableProcessor(String channelPrefix, Map busMap)
        {
            this.channelPrefix=channelPrefix;
            this.busMap=busMap;
        }
        public void doProcess(Object busSignal) {
            Object pluggable=((RemovePluggable)busSignal).getPluggable();
         
            remove(pluggable);
        }

        /**
         * The ChannelMap receives objects to be unplugged from various
         * channels. Using reflection it determines if any of the methods on the
         * object begin with "channel". If so these are removed from any
         * channels
         * 
         * @param aComponent
         *            The object to unplug from various channels.
         */
        private final void remove(Object aComponent) {
            //unregister aComponent
            Class aComponentClass = (Class) aComponent.getClass();
            Method[] aComponentMethods = aComponentClass.getMethods();

            try {

                for (int i = 0; i < aComponentMethods.length; i++) {
                    String methodName = aComponentMethods[i].getName();

                    if (methodName.startsWith(channelPrefix)) {
                        //This is a valid channel so we must unregister
                        Class[] c = aComponentMethods[i].getParameterTypes();
                        unRegisterMethodName(c[0].getName(), aComponent);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        /**
         * A method starting with "channel" was found and requires that it be
         * removed from the bus.
         * 
         * @param signalName
         *            The parameter/signal name found for the channel.
         * @param aComponent
         *            The component that has the channel.
         */
        private final void unRegisterMethodName(String signalName,
                Object aComponent) {

            //Check to see if the method name is in the HashMap
            if (busMap.containsKey(signalName)) {
                //contains value

                //Tell the channel to remove the component
                IProcessor channel = (IProcessor) busMap.get(signalName);

                //remove aComponent from channel
                channel.doProcess(new RemoveChannelListener(aComponent));
            }

        }
    
}
