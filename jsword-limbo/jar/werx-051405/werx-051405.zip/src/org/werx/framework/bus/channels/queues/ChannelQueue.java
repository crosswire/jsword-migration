/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus.channels.queues;


import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;

import org.werx.framework.bus.channels.interfaces.IChannelList;
import org.werx.framework.bus.channels.interfaces.IteratorFactory;
import org.werx.framework.bus.channels.processors.AddChannelProcessor;
import org.werx.framework.bus.channels.processors.ClearChannelProcessor;
import org.werx.framework.bus.channels.processors.RemoveChannelProcessor;
import org.werx.framework.bus.channels.processors.SignalProcessor;
import org.werx.framework.bus.channels.signals.ClearChannel;
import org.werx.framework.bus.channels.signals.RemoveChannelListener;
import org.werx.framework.commons.interfaces.IProcessor;
import org.werx.framework.commons.processors.MethodInstancePair;
import org.werx.framework.commons.processors.ProcessorMap;

/**
 * ChannelQueue does
 */
public class ChannelQueue implements IProcessor, IChannelList {

    
	LinkedHashSet channel = new LinkedHashSet();

    public static final IteratorFactory FIFO = FIFOIteratorFactory.getIteratorFactory();
    public static final IteratorFactory LIFO = LIFOIteratorFactory.getIteratorFactory();
    private ProcessorMap processors;
    private IteratorFactory iteratorFactory;


    public ChannelQueue() {
        this(LIFO);
    }

    public ChannelQueue(IteratorFactory iteratorFactory) {
        this.iteratorFactory = iteratorFactory;
       
        Map map=new LinkedHashMap();
        map.put(ClearChannel.class.getName(), new ClearChannelProcessor(this));
        map.put(MethodInstancePair.class.getName(), new AddChannelProcessor(this));
        map.put("default", new SignalProcessor(this));
        map.put(RemoveChannelListener.class.getName(), new RemoveChannelProcessor(this));
        processors=new ProcessorMap(map);
    }

    public void doProcess(Object theSignal) {
        processors.doProcess(theSignal);
    }

    public void add(MethodInstancePair mip) {

  
            channel.add(mip);
         
    }

    public void remove(Object instance) {

        channel.remove(instance);
       

    }

    public void send(Object message) {
		 
        try {
            
            Iterator it=null;
            synchronized (channel) {
                it = iteratorFactory.iterator(((LinkedHashSet)channel.clone()).toArray());
            }
            while (it.hasNext())
                ((MethodInstancePair) it.next()).doProcess(message);

        } catch (Exception e) {
            //Nothing to do...Messaging from here
            //can be dangerous and recursive.
            e.printStackTrace();
        }

    }

    public void clear() {
        channel.clear();
       
    }


}

