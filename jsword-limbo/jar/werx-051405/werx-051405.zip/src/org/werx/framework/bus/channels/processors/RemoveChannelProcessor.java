/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.processors;

import org.werx.framework.bus.channels.interfaces.IChannelList;
import org.werx.framework.bus.channels.signals.RemoveChannelListener;
import org.werx.framework.commons.interfaces.IProcessor;

/**
 * Generic channel processor for removing any
 * instance from an IChannelList
 */
public class RemoveChannelProcessor implements IProcessor
{
    private final IChannelList channel;

    public RemoveChannelProcessor(IChannelList channel)
    {
        this.channel=channel;
    }
    
    /* 
     * As with AddChannelProcessor the down casting
     * here is an acceptable trade off. Benefits are
     * delegation, separation of concerns, and generic
     * mechanism for removing .  
     * @see org.werx.framework.commons.interfaces.IProcessor#doProcess(java.lang.Object)
     */
    public void doProcess(Object o)
    {
        RemoveChannelListener signal = (RemoveChannelListener) o;     
        remove(signal.getChannelToRemove());
    }
    private void remove(Object toRemove) {
        channel.remove(toRemove);

    }
  
}