/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.commons.commands;

/**
 * @author Bradlee
 *
 *
 */
public class Executor {
    
    public Executor(ICommand toExecute)
    {
        toExecute.execute();
    }

}
