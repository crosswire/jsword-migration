package org.werx.framework.commons.processors;


public class MethodInstancePairRunner implements Runnable{
	
		private final MethodInstancePair mip;
		private final Object signal;
		public MethodInstancePairRunner(MethodInstancePair mip, Object signal)
		{
			this.mip=mip;
			this.signal=signal;
			
		}
		
		public void run()
		{
			mip.doProcess(signal);
		}
	}


