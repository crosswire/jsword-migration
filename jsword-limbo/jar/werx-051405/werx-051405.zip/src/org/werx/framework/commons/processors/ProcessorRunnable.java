/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.commons.processors;

import org.werx.framework.commons.interfaces.IProcessor;

/**
 * @author Bradlee
 *
 */
public class ProcessorRunnable implements Runnable {
    
    private final IProcessor processor;
    private final Object signal;
    public ProcessorRunnable(IProcessor processor, Object signal)
    {
        this.processor=processor;
        this.signal=signal;
    }
    
    public void run() {
        processor.doProcess(signal);

    }

}
