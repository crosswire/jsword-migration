/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus.channels.channel;

/**
 * 
 */

import org.werx.framework.bus.channels.interfaces.IChannel;

public class ChannelProxy implements IChannel {

	private final IChannel channel;

    /**
     * Creates a new channel to broadcast messages.
     * 
     * The ChannelProxy is the fundamental medium for sending
     * messages across the bus. The ChannelProxy allows for
     * varieties of concrete implementations to be set at
     * runtime. These will be specified by XML.
     *
     * @param channelName The channel/thread name for the spin lock
     */
	public ChannelProxy(IChannel channel) {
	    this.channel=channel;
		
	}


    /**
     * Send the message through the concrete channel implementation
     * 
     * The ChannelProxy is the fundamental medium for sending
     * messages across the bus. 
     *
     * @param theSignal The signal to propagate
     */
	public void doProcess(Object theSignal) {
		
		channel.doProcess(theSignal);
	}

    /**
     * Stop this channel and channel proxy
     *
     * @param theSignal The signal to propagate
     */
    public void stop()
    {
        channel.stop();
    }




}

