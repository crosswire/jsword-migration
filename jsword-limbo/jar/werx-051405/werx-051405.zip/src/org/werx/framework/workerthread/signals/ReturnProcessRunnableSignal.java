/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.workerthread.signals;

import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.framework.bus.signals.BusSignal;

/**
 * @author Bradlee
 *
 * Convenience class used with the ProcessRunnableSignal
 * to send back the results of processing.
 */
public class ReturnProcessRunnableSignal extends BusSignal implements ISwingSignal {
	private IRunnableSignal signal;

	/**
	 * Creates a new ReturnProcessRunnableSignal object.
	 * 
	 *  
	 */
	public ReturnProcessRunnableSignal(IRunnableSignal signal) {
		super(signal);
		this.signal = signal;
	}

	public Runnable getRunnable() {
		return signal.getRunnable();
	}
}