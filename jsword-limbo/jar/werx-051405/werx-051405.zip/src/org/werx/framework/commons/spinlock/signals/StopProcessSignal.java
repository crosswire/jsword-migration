/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.commons.spinlock.signals;

import org.werx.framework.bus.signals.BusSignal;


/**
 * @author Bradlee
 *
 * Call stop on the given processName.
 */
public class StopProcessSignal extends BusSignal {

	private final String processName;
	public StopProcessSignal(Object requestor, String processName)
	{
		super(requestor);
		this.processName=processName;
	}
	
	public String getProcessName()
	{
		return processName;
		
	}
}