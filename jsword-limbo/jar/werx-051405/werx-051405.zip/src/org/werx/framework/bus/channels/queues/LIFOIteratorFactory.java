/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.queues;

import java.util.Iterator;

import org.werx.framework.bus.channels.interfaces.IteratorFactory;

/**
 * LIFOIteratorFactory returns iterator for reverse
 * iteration over objects in an array.
 * 
 * @author Bradlee
 *  
 */
public class LIFOIteratorFactory implements IteratorFactory {

    private static IteratorFactory factory;

    private LIFOIteratorFactory() {

    }

    public static synchronized IteratorFactory getIteratorFactory() {
        if (factory == null) {
            factory = new LIFOIteratorFactory();
        }
        return factory;
    }

    public Iterator iterator(Object[] arr) {
        return new LIFOIterator(arr);
    }

    private class LIFOIterator implements Iterator {

        int current = 0;

        private final Object[] channelArr;

        public LIFOIterator(Object[] arr) {
            this.channelArr = arr;
            current=arr.length;
        }

        public boolean hasNext() {
            return current > 0;
        }

        public Object next() {
            //Pre-decrement to avoid
            //boundary condition.
            return channelArr[--current];
        }

        //Remove is used here only in the context
        //of the iterator. It does not modify the
        //underlying collection.
        public void remove() {
            current--;

        }
    }

}