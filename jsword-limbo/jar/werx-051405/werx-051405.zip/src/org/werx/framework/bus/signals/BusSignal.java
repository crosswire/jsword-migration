package org.werx.framework.bus.signals;
/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

//
/**
 * @author Bradlee
 * Convenience class taht carries the requestors hashcode as the
 * return address for a signal class. The isConsumed flag may be
 * used in instances where mutliple plug-ins might process messages
 * as they come across the bus. The isConsumed also may be used by
 * error handlers plugged into a channel to return errors or log
 * errors if a message is not handled on a channel. The normal 
 * LIFO processing of elements on a channel ensures that the first
 * items plugged in are the last to receive a signal. Therefore error
 * handlers can check the flag after other handlers on the channel
 * have had a shot at the message.
 * 
 * The immutable error message associated with this object represent
 * a generic OK. Sinci it is attached to static final it doesn't burn
 * memory with mutliple instances. The errorMsg is settable but is
 * initially set to the ok message.
 * 
 * Note ABSTRACT class
 * 
 */
public abstract class BusSignal implements java.io.Serializable, IBusSignal {

	private int requestorAddress;

	private boolean hasReturnAddress;

	private boolean isConsumed = false;

	//Standard message indicating everything is fine.
	public static final IErrorMessage okMessage = new ImmutableErrorMessage();

	//Starts with message set to okay.
	private IErrorMessage errorMsg = okMessage;

	//One way signal...
	protected BusSignal() {
		hasReturnAddress = false;
	}
	
	
	/**
	 * 
	 * This is used by return signals to send messages back
	 * to the originator. This constructor grabs the originators
	 * address from the incoming bus signal. Since it is off an
	 * interface it isn't strictly necessary to use the hashcode
	 * as the address but this is generally usefull.
	 * 
	 * @param originator
	 */
	protected BusSignal(IBusSignal originator) {
		requestorAddress = originator.getReturnAddress();
		hasReturnAddress = true;
	}

	//For the originator
	/**
	 * Constructor for the BusSignal object.
	 * 
	 * @param theRequestor
	 *            Description of the Parameter
	 */
	protected BusSignal(Object theRequestor) {
		requestorAddress = theRequestor.hashCode();
		hasReturnAddress = true;
	}

	public int getReturnAddress() {
		return requestorAddress;
	}

	/**
	 * Returns the name of the concrete class that inherits from this abstract
	 * classs
	 * 
	 * @return String the class name without package
	 */
	public String getSignalName() {
		String toParse = this.getClass().getName();

		return toParse.substring(toParse.lastIndexOf(".") + 1);
	}

	/**
	 * isMyAddress method to check for if an objects hashcode is the same as the
	 * initial requestor
	 * 
	 * @param toCheck
	 *            Description of the Parameter
	 * @return boolean indicates if it belongs to the object
	 */
	public boolean isMyAddress(Object toCheck) {
		return hasReturnAddress && (toCheck.hashCode() == requestorAddress);
	}

	/**
	 * Indicates that a message has been consumed by one or more of the
	 * handlers. This might be checked by an error handler to determine if the
	 * message has been consumed or not. May be safely ignored if it is not
	 * required.
	 */
	public void setConsumed(boolean consumed) {
		this.isConsumed = consumed;
	}

	/**
	 * Set the error message associated with this signal. By default the error
	 * message indicates that everything is okay by using the static
	 * ImmutableErrorMessage in this class
	 */
	public void setErrorMessage(IErrorMessage msg) {
		this.errorMsg = msg;
	}

	/**
	 * Return the error message associated with this signal.
	 */
	public IErrorMessage getErrorMessage() {
		return errorMsg;
	}

	/**
	 * getSignalConnector returns the signal connector to use in propagating the
	 * message.
	 * 
	 * @return boolean indicates if some handler has used this message and has
	 *         set the flag to consumed.
	 */
	public boolean isConsumed() {
		return isConsumed;
	}

	public String toString() {

		StringBuffer returnBuffer = new StringBuffer();
		returnBuffer.append("[Signal: " + this.getClass().getName() + "\n");

		Class clazz = this.getClass();
		while (!clazz.getName().equals(java.lang.Object.class.getName())) {

			setBuffer(clazz.getDeclaredFields(), returnBuffer);
			clazz = clazz.getSuperclass();
		}

		returnBuffer.append("]\n");

		return returnBuffer.toString();
	}

	private void setBuffer(Field[] fields, StringBuffer buffer) {
		for (int i = 0; i < fields.length; i++) {
			fields[i].setAccessible(true);
			try {
				if (!(Modifier.isFinal(fields[i].getModifiers()) && Modifier
						.isStatic(fields[i].getModifiers()))) {
					buffer.append(fields[i].getName() + ":"
							+ fields[i].get(this) + "\n");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}
}