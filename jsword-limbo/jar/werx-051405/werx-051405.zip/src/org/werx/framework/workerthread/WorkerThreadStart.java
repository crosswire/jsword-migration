package org.werx.framework.workerthread;

import java.util.LinkedHashMap;
import java.util.Map;

import org.werx.framework.commons.processors.ProcessorMap;
import org.werx.framework.commons.spinlock.SpinLock;

public class WorkerThreadStart {
	
	public WorkerThreadStart()
	{
		boolean isDaemonThread=true;
		Map processorMap = new LinkedHashMap();
		
		processorMap.put("default",new RunnableProcessor());
		ProcessorMap processors = new ProcessorMap(processorMap);
		SpinLock workerSpinLock = new SpinLock("workerThread",processors,isDaemonThread);
		new WorkerThreadController(workerSpinLock);
	}

}
