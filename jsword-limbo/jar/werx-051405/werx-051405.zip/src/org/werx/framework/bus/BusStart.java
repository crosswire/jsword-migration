package org.werx.framework.bus;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import org.werx.framework.bus.channels.channelmap.processors.AddPluggableProcessor;
import org.werx.framework.bus.channels.channelmap.processors.ClassPropagationProcessor;
import org.werx.framework.bus.channels.channelmap.processors.InterfacePropagationProcessor;
import org.werx.framework.bus.channels.channelmap.processors.RemovePluggableProcessor;
import org.werx.framework.bus.channels.channelmap.processors.ResetBusProcessor;
import org.werx.framework.bus.channels.signals.AddPluggable;
import org.werx.framework.bus.channels.signals.RemovePluggable;
import org.werx.framework.bus.signals.ResetBusSignal;
import org.werx.framework.commons.processors.ProcessorList;
import org.werx.framework.commons.processors.ProcessorMap;
import org.werx.framework.commons.spinlock.SpinLock;

public class BusStart {
	
	public BusStart()
	{
		String channelPrefix="channel";
		String mainThreadName = "MainBus";
		boolean isDaemonThread=false;
		HashMap sharedBusMap = new HashMap();
		Map processorMap = new LinkedHashMap();
		
		LinkedList listOfDefaultProcessors = new LinkedList();
		listOfDefaultProcessors.add(new ClassPropagationProcessor(sharedBusMap));
		listOfDefaultProcessors.add(new InterfacePropagationProcessor(sharedBusMap));
		ProcessorList defaultProcessor = new ProcessorList(listOfDefaultProcessors);
		
		processorMap.put("default",defaultProcessor);
		processorMap.put(ResetBusSignal.class.getName(),new ResetBusProcessor(sharedBusMap));
		processorMap.put(AddPluggable.class.getName(), new AddPluggableProcessor(channelPrefix, sharedBusMap));
		processorMap.put(RemovePluggable.class.getName(), new RemovePluggableProcessor(channelPrefix, sharedBusMap));
		

		processorMap.put("default", defaultProcessor);
        
		ProcessorMap processors = new ProcessorMap(processorMap);
		
		SpinLock mainLock = new SpinLock(mainThreadName,processors,isDaemonThread);
		Bus bus = new Bus(mainLock);
		ReflectionBus rBus = new ReflectionBus();
		rBus.setBus(bus);
	}

}
