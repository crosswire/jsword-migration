/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.commons.processors;

/**
 * 
 * MethodInstancPair effectively binds the object instance
 * to the Method. Java doesn't automatically do this binding
 * so one either saves the information via an object like this
 * or uses reflection for each and every broadcast.
 * 
 */
import java.lang.reflect.Method;

import org.werx.framework.commons.interfaces.IProcessor;


public final class MethodInstancePair implements IProcessor{

	public final Object instance;

	public final Method method;

	
	/**
	 * 
	 * The MethodInstancePair constructor sets the method
	 * to accessible so that private/protected/package 
	 * methods on instance or instances super class 
	 * are available for invoking. This won't work with
	 * an applet. The signature would need to be changed
	 * to allow for runtime checking of context.
	 * 
	 * @param m The Method object discovered at plug in time.
	 * @param o The Object/instance that the Method resides on.
	 * 
	 */
	public MethodInstancePair(Method m, Object o) {
		this.instance = o;
		this.method = m;
		//Allows invocation of inner class and non-public
		//class methods as well as private channels. This
		//will not work with JApplets as it is a security
		//violation.
		method.setAccessible(true);
	}

	
	/* 
	 * This method calls the stored method on the stored
	 * Object/instance and passes in the received signal.
	 * 
	 * @see org.werx.framework.commons.interfaces.IProcessor#doProcess(java.lang.Object)
	 */
	public void doProcess(Object signal) {
		
		try {
			method.invoke(instance, new Object[] { signal });
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}