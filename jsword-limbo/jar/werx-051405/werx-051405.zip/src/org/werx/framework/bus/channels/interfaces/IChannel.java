/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.interfaces;

import org.werx.framework.commons.interfaces.IProcessor;
import org.werx.framework.commons.interfaces.IStoppable;

/**
 * The interface for all channel instances. Different
 * concrete channel types may be created but they
 * must implement this interace to be used by the bus.
 */
public interface IChannel extends IStoppable, IProcessor {

}
