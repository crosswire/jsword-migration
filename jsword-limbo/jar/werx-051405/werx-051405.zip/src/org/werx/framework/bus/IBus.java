/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus;


/**
 * 
 *  
 */
public interface IBus {
	

	/**
	 * The contract for the bus. It accepts any object for broadcast
	 * via this method.
	 * 
	 * @param theMessageToSend
	 */
	public abstract void broadcast(Object theMessageToSend);

	/**
	 * Unplug method to remove an object from the bus.
	 * 
	 * @param aComponent
	 *            The object to be removed from bus channels.
	 */
	public abstract void unplug(Object aComponent);

	/**
	 * plug method to plug objects into bus channels. This uses reflection to
	 * figure out which channels the object is listenting on. Any object with a
	 * method starting with channelPrefix is added to that channel.
	 * 
	 * @param aComponent
	 *            The object to plug into the bus
	 */
	public abstract void plug(Object aComponent);

	/**
	 * resetbus ()
	 * 
	 * Notifies the bus to get rid of all channels.
	 */
	public abstract void resetbus();

	
}