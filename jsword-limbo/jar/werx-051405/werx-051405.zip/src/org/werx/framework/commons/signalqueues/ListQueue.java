/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.commons.signalqueues;

import java.util.List;

/**
 * @author Bradlee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ListQueue implements ISignalQueue{

    List queue;
    public ListQueue(List queue)
    {
        this.queue=queue;
    }
    /* (non-Javadoc)
     * @see org.werx.framework.commons.signalqueues.ISignalQueue#add(java.lang.Object)
     */
    public void add(Object signal) {
        queue.add(signal);
        
    }

    /* (non-Javadoc)
     * @see org.werx.framework.commons.signalqueues.ISignalQueue#remove()
     */
    public Object remove() {
        // TODO Auto-generated method stub
        return queue.remove(0);
    }

    /* (non-Javadoc)
     * @see org.werx.framework.commons.signalqueues.ISignalQueue#isEmpty()
     */
    public boolean isEmpty() {
        // TODO Auto-generated method stub
        return queue.isEmpty();
    }

    /* (non-Javadoc)
     * @see org.werx.framework.commons.signalqueues.ISignalQueue#size()
     */
    public int size() {
        // TODO Auto-generated method stub
        return queue.size();
    }

    /* (non-Javadoc)
     * @see org.werx.framework.commons.signalqueues.ISignalQueue#clear()
     */
    public void clear() {
        queue.clear();
        
    }

}
