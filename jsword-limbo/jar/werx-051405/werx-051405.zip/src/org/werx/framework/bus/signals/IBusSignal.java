/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus.signals;

/**
 * 
 */
public interface IBusSignal {

	/**
	 * Returns the name of the concrete class that inherits from this abstract
	 * classs
	 * 
	 * @return String the class name without package
	 */
	public abstract String getSignalName();

	/**
	 * isMyAddress method to check for if an objects hashcode is the same as the
	 * initial requestor
	 * 
	 * @param toCheck
	 *            Description of the Parameter
	 * @return boolean indicates if it belongs to the object
	 */
	public abstract boolean isMyAddress(Object toCheck);

	/**
	 * Returns the address the message is sent from.
	 * 
	 * @param toCheck
	 *            Description of the Parameter
	 * @return boolean indicates if it belongs to the object
	 */
	public abstract int getReturnAddress();

	/**
	 * Set the error message associated with this signal. By default the error
	 * message indicates that everything is okay by using the static
	 * ImmutableErrorMessage in this class
	 */
	public void setErrorMessage(IErrorMessage msg);

	/**
	 * Return the error message associated with this signal.
	 */
	public IErrorMessage getErrorMessage();

	/*
	 * Indicates if this signal has been used or consumed
	 */
	public void setConsumed(boolean consumed);

	/**
	 * getSignalConnector returns the signal connector to use in propagating the
	 * message.
	 * 
	 * @return boolean indicates if some handler has used this message and has
	 *         set the flag to consumed.
	 */
	public boolean isConsumed();

}