package org.werx.framework.commons.commands;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
public interface ICommand
{
    /**
     * All command objects must implement an execute method.
     */
    public void execute();
}