/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.workerthread;

import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.interfaces.IProcessor;
import org.werx.framework.workerthread.signals.IRunnableSignal;
import org.werx.framework.workerthread.signals.ReturnProcessRunnableSignal;

/**
 * @author Bradlee
 * 
 * A Processor for receiving and running IRunnableSignals. This is used in
 * processor lists or maps for processing this type of signal. It should be
 * keyed IRunnableSignal.class wherever it is used so that casting is correct.
 *  
 */
public class RunnableProcessor implements IProcessor {

    /*
     * Thread is in the spin lock. This is the callback mechanism for it to run
     * on the thread. This could be on a different object if desired.
     */
    public void doProcess(Object busSignal) {

        //System.out.println("Run " + busSignal);
        //This may be used in lists, chains or maps
        //where the key may be of a different sort
        //IRunnableSignal. While that is the wrong use...
        if (busSignal instanceof IRunnableSignal) {
            IRunnableSignal signal = (IRunnableSignal) busSignal;
            signal.run();
            ReflectionBus.broadcast(new ReturnProcessRunnableSignal(signal));
        }
    }

}