package org.werx.framework.controllers;

import java.lang.reflect.Method;
import java.util.Map;

import org.werx.framework.commons.processors.MethodInstancePair;

public abstract class AbstractController {

	Map processors;
	public AbstractController(Map processors)
	{
		this.processors=processors;
	}
	
	public void addProcessor(Object processor)
	{
		
		Method[] methods = processor.getClass().getMethods();
		for (int i = 0; i < methods.length; i++) {
			// Do process method with one and only one
			// parameter.
			if (methods[i].getName().equals("doProcess")
					&& methods[i].getParameterTypes().length == 1) {
				Class signalClass = methods[i].getParameterTypes()[0];


				processors.put(signalClass.getName(), new MethodInstancePair(
						methods[i], processor));
			}
		}
	}
	
	public void doProcess(Object busSignal)
	{
		
		MethodInstancePair processor = (MethodInstancePair) processors.get(busSignal.getClass().getName());
		if(processor!=null)
		{

			processor.doProcess(busSignal);
		}
		Class[] signalInterfaces = busSignal.getClass().getInterfaces();
		for(int i=0;i<signalInterfaces.length;i++)
		{
			processor = (MethodInstancePair) processors.get(signalInterfaces[i].getClass().getName());
			if(processor!=null)
			{
				processor.doProcess(busSignal);
			}
		}
	}
}
