/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.commons.processors;

import java.util.Map;

import org.werx.framework.commons.interfaces.IProcessor;



/**
 * @author Bradlee
 *
 * ProcessorMap to map various processors to Class keys.
 * 
 */
public class ProcessorMap implements IProcessor {

    IProcessor defaultProcessor;
    Map processors;

    public ProcessorMap(Map processorMap)
    {
        
        this.processors=processorMap;
       
    }
  
    /**
     * 
     * Default processor is used if the incoming
     * Object's Class is not found as a key in the 
     * processors Map. This could be an error handler
     * or simply the default behavior.
     * 
     * @param process
     */
    public void setDefault(IProcessor process)
    {
       processors.put("default",process);
    }
    
    /**
     * 
     * This method adds a processor associated with the given
     * Class. The Class name is the key for the map. 
     * @param c
     * @param processor
     */
    public void setProcessor(String name, IProcessor processor)
    {
        processors.put(name,processor);
    }
    
    /**
     * 
     * This method adds a processor associated with the given
     * Class. The Class name is the key for the map. 
     * @param c
     * @param processor
     */
    public void setProcessor(Class c, IProcessor processor)
    {
        processors.put(c.getName(),processor);
    }
    /* 
     * 
     * Fetches the processor from the processors map based on the
     * name of the instance's Class name. If the map doesn't contain
     * an instance then the default is used. Note that default is a required
     * class.
     * @see org.werx.framework.commons.interfaces.IProcessor#doProcess(java.lang.Object)
     */
    public void doProcess(Object busSignal) {
       
        IProcessor processor = (IProcessor) processors.get(busSignal.getClass().getName());
        if (processor==null)
        {
          processor=(IProcessor) processors.get("default");
        }
        //Needn't have default behavior...
        if(processor!=null)
            processor.doProcess(busSignal);
    }
    //Give the GC a clue...
    public void clear()
    {
    
        processors.clear();
        processors=null;
        defaultProcessor=null;
    }
    

}
