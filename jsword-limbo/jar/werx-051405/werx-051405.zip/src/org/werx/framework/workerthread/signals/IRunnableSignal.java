/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.workerthread.signals;

import org.werx.framework.bus.signals.IBusSignal;

/**
 * @author Bradlee
 *
 * Siginal to pass a Runnable object to a worker thread.
 */

public interface IRunnableSignal extends IBusSignal, Runnable {

	public Runnable getRunnable();
}