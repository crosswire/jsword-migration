/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.springutils;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Logger;





/**
 * @author Bradlee
 *

 */
public class Bootstrap {
    Logger logger=Logger.getLogger(Bootstrap.class.getName());
    public Bootstrap(String[] args)
    {
		for (int i=0;i<args.length;i++)
		{
		   
		    new Bootstrap(args[i]);
		    
		}
    }
  
    public Bootstrap(String fileName)
    {
       
		//Reflection rigamorole is only necessary
		//to make sure the class compiles even if
		//the user is not using Spring and the
		//Spring jar is not on the path.
       
				try {
					Class beanFactory = Class.forName("org.springframework.beans.factory.xml.XmlBeanFactory");
					Class urlResource = Class.forName("org.springframework.core.io.UrlResource");
					Class resourceClass = Class.forName("org.springframework.core.io.Resource");
					Constructor urlResourceConstructor = urlResource.getConstructor(new Class[]{URL.class});
					Object urlResourceInstance = urlResourceConstructor.newInstance(new Object[]{new URL(fileName)});
					Constructor beanFactoryConstructor = beanFactory.getConstructor(new Class[]{resourceClass});
					
					Object beanFactoryInstance=beanFactoryConstructor.newInstance(new Object[]{urlResourceInstance});
					Method preInstantiateSingletons = beanFactory.getMethod("preInstantiateSingletons",new Class[]{});
					preInstantiateSingletons.invoke(beanFactoryInstance,new Object[]{});
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

            
        
 		
       
    }
   
    public static void main(String[] args)
    {
        new Bootstrap(args);
    }
    
    private class BootstrapRunnable implements Runnable
    {
        String fileName;
        public BootstrapRunnable(String fileName)
        {
            this.fileName=fileName;
        }
        
        public void run()
        {
            new Bootstrap(fileName);
        }
    }
}
