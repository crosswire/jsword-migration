/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.commons.interfaces;


/**
 * @author Bradlee
 *
 * The interface for interoperation for maps, trees, chain of commands
 * or any other object oriented structure in the system.
 */
public interface IProcessor {
	/**
	 * Called to delegate processing to child objects.
	 * There isn't a return on this method as this
	 * is intended for true delegation tasks where
	 * the owner may delegate and forget.
	 * 
	 * @param toProcess
	 */
	public void doProcess(Object toProcess);


}
