/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.channelmap.processors;

import java.util.Map;

import org.werx.framework.commons.interfaces.IProcessor;

/**
 * 
 */
public class ClassPropagationProcessor implements IProcessor {
    Map busMap;

    public ClassPropagationProcessor(Map busMap) {
        this.busMap = busMap;
    }

    public void doProcess(Object theSignal) {
        //System.out.println(theSignal.getClass().getName());
        //Concrete classes...
        Class c = theSignal.getClass();

        //Walk up the class hierarchy of the signal and
        //broadcast on each channel. Stop when the the
        //Object class is found.
        while (c != null) {
			//System.out.println(c.getName());
            IProcessor channel = (IProcessor) busMap.get(c.getName());
			//System.out.println(channel);
			//System.out.println("****");
            if (channel != null) {

                channel.doProcess(theSignal);

            }
            c = c.getSuperclass();

        }
    }

}