/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.processors;

import org.werx.framework.bus.channels.interfaces.IChannelList;
import org.werx.framework.commons.interfaces.IProcessor;

/**
 * Generic signal processor object that takes
 * received signals and propagates them to the channel
 */
public class SignalProcessor implements IProcessor
{
    private final IChannelList channel;
    public SignalProcessor(IChannelList channel)
    {
        this.channel=channel;
    }
    public void doProcess(Object o)
    {
        channel.send(o);
        
    }
   
  
}
