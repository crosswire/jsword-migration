/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.queues;

import java.util.Iterator;

import org.werx.framework.bus.channels.interfaces.IteratorFactory;

/**
 * FIFOIteratorFactory returns an Iterator that iterates in
 * forward order over the objects in the array.
 * 
 * @author Bradlee
 *  
 */
public class FIFOIteratorFactory implements IteratorFactory {

    private static IteratorFactory factory;

    private FIFOIteratorFactory() {

    }

    public static synchronized IteratorFactory getIteratorFactory() {
        if (factory == null) {
            factory = new FIFOIteratorFactory();
        }
        return factory;
    }

    public Iterator iterator(Object[] arr) {
        return new FIFOIterator(arr);
    }

    private class FIFOIterator implements Iterator {

        int current = 0;

        private final Object[] channelArr;

        public FIFOIterator(Object[] arr) {
            this.channelArr = arr;
        }

        public boolean hasNext() {
            return current < channelArr.length;
        }

        public Object next() {
            return channelArr[current++];
        }

        //Remove is used here only in the context
        //of the iterator. It does not modify the
        //underlying collection.
        public void remove() {
            current++;

        }
    }
}