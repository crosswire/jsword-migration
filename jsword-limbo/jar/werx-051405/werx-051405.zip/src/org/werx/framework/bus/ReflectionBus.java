/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus;


/**
 * The ReflectionBus is the heart of the framework. Objects "plug in"
 * to the bus. At that point reflection determines what channels the object
 * is listening on and registers it on those channels. When a signal is propagated
 * on that channel, all the objects on that channel are notified.
 * 
 * The ReflectionBus is a static wrapper around a standard bus object. The bus object
 * is used in other subpackages that themseleves plug into this bus. I effect creating
 * a bus of buses.
 *
 * Imporant to note: channels are defined by message name on the "channel" methods
 * parameter. 
 * 
 */

/**
 * broadcast ()
 * 
 * broadcast method used by any object to propagate a signal across the bus.
 * 
 * @param theMessageToSend
 *            All signals must descend from IBusSignal
 *  
 */
public class ReflectionBus {
	private static Bus bus;

	public void setBus(Bus busIn)
	{
	    bus=busIn;
	}
	/**
	 * Unplug method to remove an object from the bus.
	 * 
	 * @param aComponent
	 *            The object to be removed from bus channels.
	 */
	public static void broadcast(Object theMessageToSend) {
		bus.broadcast(theMessageToSend);
	}

	/**
	 * Unplug method to remove an object from the bus.
	 * 
	 * @param aComponent
	 *            The object to be removed from bus channels.
	 */
	public static void unplug(Object aComponent) {
		bus.unplug(aComponent);
	}

	/**
	 * plug method to plug objects into bus channels. This uses reflection to
	 * figure out which channels the object is listenting on. Any object with a
	 * method starting with channelPrefix is added to that channel.
	 * 
	 * @param aComponent
	 *            The object to plug into the bus
	 */
	public static void plug(Object aComponent) {
		bus.plug(aComponent);
	}

	/**
     * resetbus ()
     * 
     * Notifies the bus to get rid of all channels.
     */
    public static void resetbus() {
    	bus.resetbus();
    }

	
}

// ReflectionBus
