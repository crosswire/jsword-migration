/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.commons.processors;

import java.util.Iterator;
import java.util.List;

import org.werx.framework.commons.interfaces.IProcessor;


/**

 */
public class ProcessorList implements IProcessor {

    IProcessor[] processors = new IProcessor[64];
   
    int current=0;
    int load=0;
    
    
    
    public ProcessorList(List list)
    {
        Iterator it = list.iterator();
        while(it.hasNext())
        {
            add((IProcessor) it.next());
        }
    }
    
    //TODO Currently there are only a few processors
    //plugged into the list at any time. Max of 3 or 4
    //so resizing is never an issue. The resizing code
    //is here but unused and untested. If necessary it
    //could be added in but that is unlikely.
    public void add(IProcessor processor)
    {
        /*
       if (load==0)
           doLoad();
       if(current>load)
           resize();
           */
       
        processors[current++]=processor;
    }
    public void doProcess(Object busSignal) {
        
        int i=0;
        IProcessor processor;
        while(processors[i]!=null)  
            processors[i++].doProcess(busSignal);
       
    }
    
    private void doLoad()
    {
        //Resize at 70%
        load=(processors.length*7)/10;
    }
    
    private void resize()
    {
        IProcessor[] newProcessors=new IProcessor[processors.length*2];
        int i=-1;
        IProcessor processor;
        while(processors[++i]!=null)  
            newProcessors[i]=processors[i];
       processors=newProcessors;
       doLoad();
    }

}
