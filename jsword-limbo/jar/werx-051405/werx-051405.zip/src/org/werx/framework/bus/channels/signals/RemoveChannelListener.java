/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.signals;


/**
 * @author Bradlee
 *
 * The RemoveChannelListener object identifies
 * the object being carried as one that the processors
 * should remove. These objects could be cached to 
 * improve performance and memory load
 */
public class RemoveChannelListener {
    
    private Object toRemove;
    public RemoveChannelListener(Object toRemove)
    {
        this.toRemove=toRemove;
      }
    
    public Object getChannelToRemove()
    {
        return toRemove;
    }

}
