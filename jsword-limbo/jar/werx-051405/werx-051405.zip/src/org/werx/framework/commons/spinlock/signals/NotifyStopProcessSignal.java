/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.commons.spinlock.signals;

import org.werx.framework.bus.signals.BusSignal;


/**
 * @author Bradlee
 *
 * Notify that a processor is stopping.
 */
public class NotifyStopProcessSignal extends BusSignal {

	private final String name;
	public NotifyStopProcessSignal(String name)
	{
		this.name=name;
		
	}
	
	public String getName()
	{
		return name;
	}


}