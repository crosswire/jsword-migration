/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus.signals;

/**
 * 
 */

public interface IErrorMessage {
	/**
	 * The key for the String to use as a display or logging value.
	 */
	public static final String ERROR_MESSAGE = "ErrorMessage";

	/**
	 * Error Actions are used to pass values for triggering command objects or
	 * for if/else statements to help a client deal with errors.
	 *  
	 */
	public static final String ERROR_ACTION = "ErrorAction";

	/**
	 * Sets the error message to send back.
	 */
	public void setErrorMessage(String msg);

	/**
	 * Gets the ErrorAction to be used in handling the error.
	 */
	public String getErrorAction();

	/**
	 * Sets the error action to signal to the listener what error has occured.
	 * The user may use this to set up error handling procedures.
	 */
	public void setErrorAction(String msg);

	/**
	 * Gets the errorMessage attribute of the IErrorMessage
	 */
	public String getErrorMessage();

	/**
	 * Add attributes to the error message
	 *  
	 */
	public void putValue(Object key, Object value);

	/**
	 * Get attributes from the error message.
	 *  
	 */
	public Object getValue(Object key);
}

