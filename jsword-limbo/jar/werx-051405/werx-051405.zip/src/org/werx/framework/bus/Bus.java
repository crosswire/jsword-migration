package org.werx.framework.bus;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */


import org.werx.framework.bus.channels.signals.AddPluggable;
import org.werx.framework.bus.channels.signals.RemovePluggable;
import org.werx.framework.bus.signals.ResetBusSignal;
import org.werx.framework.commons.interfaces.IProcessor;

/**
 * The Bus is the heart of the framework. Objects "plug in" to the bus. At that
 * point reflection determines what channels the object is listening on and
 * registers it on those channels. When a signal is propagated on that channel,
 * all the objects on that channel are notified.
 * 
 * The Bus uses delegation to other components that may be re-used.
 * 
 * Imporant to note: channels are defined by message name parameters.
 * 
 *  
 */
public class Bus implements IBus {
    private final IProcessor spinLock;

    /**
     * start ()
     * 
     * Loads the class and starts the bus. The spinlock is a threaded messaging
     * mechansim that makes a call to any IProcessor. It is also an IProcessor
     * object itself.
     *  
     */
    public Bus(IProcessor spinLock) {
        this.spinLock=spinLock;

    }

    // start ()

    /**
     * broadcast ()
     * 
     * Broadcast method used by any object to propagate a signal across the bus.
     * The doProcess here is called on the SpinLock object wherein the message
     * is passed off the calling thread onto the internal thread in the spin
     * lock.
     * 
     * @param theMessageToSend
     *            All signals must descend from IBusSignal
     *  
     */
    public final void broadcast(Object theMessageToSend) {
        spinLock.doProcess(theMessageToSend);

    }

    /**
     * Unplug method to remove an object from the bus. These objects are
     * unplugged based on any instance of the channel/parameter combination
     * found on the object being passed in. See the ChannelMap for more detail.
     * 
     * @param aComponent
     *            The object to be removed from bus channels.
     */
    public final void unplug(Object aComponent) {
        spinLock.doProcess(new RemovePluggable(aComponent));

    }

    /**
     * Plug method to plug objects into bus channels. This uses reflection to
     * figure out which channels the object is listenting on. Any object with a
     * method starting with channelPrefix is added to that channel.
     * 
     * The AddPluggable object is used to identify the component
     * to the internal bus processors. These could be cached for
     * memory and performance.
     * 
     * @param aComponent
     *            The object to plug into the bus
     */
    public final void plug(Object aComponent) {

        spinLock.doProcess(new AddPluggable(aComponent));

    }

    /**
     * resetbus ()
     * 
     * Notifies the bus to get rid of all channels.
     */
    public final void resetbus() {
        spinLock.doProcess(new ResetBusSignal());
       

    }


}
// ReflectionBus
