/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.workerthread.signals;

import org.werx.framework.bus.signals.BusSignal;

/**
 * @author Bradlee
 *
 * Convenience class that implements the IRunnableSignal. This signal
 * takes care of messaging to and from the source and carries the runnable
 * to the recipient thread for processing before return.
 */
public class ProcessRunnableSignal extends BusSignal implements IRunnableSignal {
	private Runnable runnable;

	public ProcessRunnableSignal(Object returnAddress, Runnable runnable) {
		super(returnAddress);
		this.runnable = runnable;
	}

	public Runnable getRunnable() {
		return runnable;
	}
	
	/* 
	 * Run the contained runnabble.
	 * @see java.lang.Runnable#run()
	 */
	public void run()
	{
	 
		runnable.run();
	}
}