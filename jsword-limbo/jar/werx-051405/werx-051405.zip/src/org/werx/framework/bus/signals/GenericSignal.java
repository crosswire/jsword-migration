/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus.signals;


/**
 * GenericSignal that can be used to carry any
 * message accross the bus and havea return address
 * In ones sense this is the coarsest level of
 * granularity for a general purpose channel.
 */

public class GenericSignal extends BusSignal {

	Object message;
	public GenericSignal(Object requestor, Object message)
	{
		super(requestor);
		this.message=message;
	}
	
	public Object getMessage()
	{
		return message;
		
	}
}