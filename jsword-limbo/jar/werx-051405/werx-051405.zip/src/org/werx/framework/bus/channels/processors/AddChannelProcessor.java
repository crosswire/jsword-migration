/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.processors;

import org.werx.framework.bus.channels.interfaces.IChannelList;
import org.werx.framework.commons.interfaces.IProcessor;
import org.werx.framework.commons.processors.MethodInstancePair;

/**
 * @author Bradlee
 * 
 * AddChannelProcessor uses the generic IChannelList interface to add new
 * instances to a channel. This
 *  
 */
public class AddChannelProcessor implements IProcessor {
    private final IChannelList channel;

    public AddChannelProcessor(IChannelList channel) {
        this.channel = channel;
    }

    /*
     * The doProcess method takes the MethodInstancePair and adds it
     * to the IChannelList. This is a delegate object that could be implemented
     * directly to avoid down casting. However, this is a generic bus component
     * that is exercised via tests and that is not considered problematic. The
     * delegation and separation of concerns is considered more important.
     * 
     * @see org.werx.framework.commons.interfaces.IProcessor#doProcess(java.lang.Object)
     */
    public void doProcess(Object o) {
      
        channel.add((MethodInstancePair) o);

    }

}