/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.commons.signalqueues;


/**
 * 
 */
public class FIFORingQueue implements ISignalQueue {
	
	Object[] queue = new Object[256];
	private int first=0;
	private int last=0;
	
	
	public void add(Object signal)
	{
		queue[last]=signal;
		incrementLast();

		if (last>=queue.length)
		{
			resizeArray();
		}

	}
	
	public Object remove()
	{
		Object signal = queue[first];
		queue[first]=null;
		incrementFirst();
		return signal;
	}
	
	public boolean isEmpty()
	{
	    return first==last;
	}

	public int size()
	{
		int size=0;
		if (first<last)
		{
			size=last-first;
		} else
		{
			size=(queue.length-first)+last;
		}
		return size;
	}
	
	private void resizeArray()
	{
		Object[] newQueue = new Object[queue.length*2];

		for (int i=0;i<queue.length;i++)
		{
			newQueue[queue.length+i-1]=queue[i];
		}
		first=queue.length+first-1;
		last=queue.length+last-1;
		queue=newQueue;
		
	}
	

	
	private void incrementFirst()
	{
		first++;
		if(first>last || first>=queue.length)
			first=last;
		
	}
	
	private void incrementLast()
	{
		last++;
		if (last>=queue.length)
			last=0;
		
	}
	
	public void clear()
	{
		queue= new Object[256];
	}
	
	
	
}
