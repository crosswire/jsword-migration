package org.werx.framework.startup;

public class Bootstrap {
	
	public Bootstrap(String[] args)
	{
		for (int i=0;i<args.length;i++)
		{
			try {
				Class c=Class.forName(args[i]);
				c.newInstance();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args)
	{
		new Bootstrap(args);
	}

}
