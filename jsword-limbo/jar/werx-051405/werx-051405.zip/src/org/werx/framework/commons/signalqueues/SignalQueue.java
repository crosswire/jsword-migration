/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.commons.signalqueues;

import java.util.LinkedList;


/**
 * @author Bradlee
 *
 * SignalQueue is the mechanism that delegates
 * to an instance of ISignalQueue. This gives
 * the ability to use different types of queues
 * in the future.
 * 
 */
public class SignalQueue implements ISignalQueue{
	
	//ISignalQueue queue = new FIFORingQueue();
    ISignalQueue queue = new ListQueue(new LinkedList());
	private boolean isRunning=true;

	public synchronized boolean blockWhileEmpty()
	{
		while(queue.isEmpty() && isRunning)
		{
			try {
				this.wait();
			} catch (InterruptedException e) {
				
			}
		}
		return false;
	}
	
	public synchronized void add(Object signal)
	{
		queue.add(signal);		
	}
	
	public synchronized Object remove()
	{
		return queue.remove();
	}

	public synchronized void setRunning(boolean isRunning)
	{
	    this.isRunning=isRunning;
	}


    public synchronized boolean isEmpty() {
       return queue.isEmpty();
    }


    public synchronized int size() {
       return queue.size();
    }

 
    public synchronized void clear() {
       queue.clear();
        
    }
	
	
}
