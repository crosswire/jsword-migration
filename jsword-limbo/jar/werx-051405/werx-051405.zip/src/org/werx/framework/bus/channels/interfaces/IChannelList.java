/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.bus.channels.interfaces;

import org.werx.framework.commons.processors.MethodInstancePair;




/**
 * 
 * Basic Channel object uses IChannelList objects to store
 * listeners and to propagate signals. This allows for
 * multiple types of lists as long as they fulfill this 
 * contract.
 * 
 */

public interface IChannelList  {

    public void send(Object instance);
	public void add(MethodInstancePair mip);
	public void remove(Object instane);
	public void clear();
	


}