/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.commons.commands;

import java.util.Iterator;
import java.util.List;


/**
 * @author Bradlee List command that aggregates other commands.
 */
public class CommandList implements ICommand {

    private List list;


    //Default is a OneShot constructor...
    public CommandList(List list) {
       
        this.list = list;
        
    }

    public void execute() {
        
        if (list != null) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                ((ICommand) it.next()).execute();
            }
          
        }

    }
   
}