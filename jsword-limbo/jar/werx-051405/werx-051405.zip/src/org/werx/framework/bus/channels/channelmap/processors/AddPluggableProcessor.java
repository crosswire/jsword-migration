/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.channelmap.processors;

import java.lang.reflect.Method;
import java.util.Map;

import org.werx.framework.bus.channels.interfaces.IChannel;
import org.werx.framework.bus.channels.queues.ChannelQueue;
import org.werx.framework.bus.channels.signals.AddPluggable;
import org.werx.framework.commons.interfaces.IProcessor;
import org.werx.framework.commons.processors.MethodInstancePair;
import org.werx.framework.commons.spinlock.SpinLock;

/**
 * @author Bradlee The AddPluggableProcessor uses reflection to find
 *         methods/channels that are plugged into the bus. It registers these
 *         methods with the appropriate channel in the channel map.
 */
public class AddPluggableProcessor implements IProcessor {
	private final String channelPrefix;

	private final Map busMap;

	/**
	 * @param channelPrefix
	 * @param busMap
	 */
	public AddPluggableProcessor(String channelPrefix, Map busMap) {
		this.channelPrefix = channelPrefix;
		this.busMap = busMap;
	}

	/*
	 * The Add The processor method that adds an object to the bus. The channels
	 * are determined by the method names.
	 * 
	 * @see org.werx.framework.commons.interfaces.IProcessor#doProcess(java.lang.Object)
	 */
	public void doProcess(Object busSignal) {
		Object pluggable = ((AddPluggable) busSignal).getPluggable();
		add(pluggable);

	}

	/**
	 * The ChannelMap receives objects to be plugged into various channels.
	 * Using reflection it determines if any of the methods on the object begin
	 * with the specified pre-fixe e.g. "channel". When found these chanels
	 * propagate signals by the same name as the parameter of the method. For
	 * example, channel(AddNewPartSignal signal) would be added to a channel for
	 * AddNewPartSignal. The channels are created dynamically at runtime.
	 * 
	 * @param aComponent
	 *            The object to plug in
	 */
	private final void add(Object aComponent) {
		// Iterate through methods.
		Class aComponentClass = (Class) aComponent.getClass();
		Method[] aComponentMethods = aComponentClass.getMethods();

		try {

			for (int i = 0; i < aComponentMethods.length; i++) {
				// Look at each method and put them in the appropriate
				// hash table.
				String methodName = aComponentMethods[i].getName();

				if (methodName.startsWith(channelPrefix)) {
					Class[] c = aComponentMethods[i].getParameterTypes();
					if (c.length == 1) {
						// This is a valid channel name so we are now going to
						// register it.
						// System.out.println(c[0].getName()+","+aComponentMethods[i]+","+aComponent);
						this.registerMethodName(c[0].getName(),
								new MethodInstancePair(aComponentMethods[i],
										aComponent));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * A method starting with the prefix e.g. "channel" was found on the object
	 * plugged into the bus. The object is being added to the channel for that
	 * signal type.
	 * 
	 * @param signalName
	 *            The name of the channel register the aComponent on.
	 * @param aComponent
	 *            The aComponent that is to listen on the channel.
	 */
	private final void registerMethodName(String signalName,
			MethodInstancePair mip) {

		IChannel channel = null;
		// Check to see if the channel name is in the HashMap
		if (busMap.containsKey(signalName)) {

			// contains value so register this component on
			// the found channel.
			channel = (IChannel) busMap.get(signalName);

		} else {
			// create a new channel since this was not
			// found in the busMap
		
			channel = new SpinLock(signalName, new ChannelQueue(), false);

			// add this component to the new channel.
			busMap.put(signalName, (Object) channel);

		}
		channel.doProcess(mip);
	}

}
