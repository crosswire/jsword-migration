/**
 * WERX2 - Java Lightweight Messaging Bus Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * 
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  
 */
package org.werx.framework.bus.channels.queues;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.werx.framework.bus.channels.interfaces.IChannelList;
import org.werx.framework.bus.channels.processors.ClearChannelProcessor;
import org.werx.framework.bus.channels.processors.RemoveChannelProcessor;
import org.werx.framework.bus.channels.processors.SignalProcessor;
import org.werx.framework.commons.interfaces.IProcessor;
import org.werx.framework.commons.processors.MethodInstancePair;
import org.werx.framework.commons.processors.ProcessorMap;


public class ChannelQueueMulticaster implements IProcessor,IChannelList {
    ProcessorMap processors;
    
    public ChannelQueueMulticaster()
    {
        //TODO Move to XML Spring configuration...
        Map map=new LinkedHashMap();
        map.put("org.werx.framework.bus.channels.signals.ClearChannel", new ClearChannelProcessor(this));
        //TODO Not used?
        // map.put("org.werx.framework.bus.channels.channel.MethodInstancePair", new AddChannelProcessor(this));
        map.put("default", new SignalProcessor(this));
        map.put("org.werx.framework.bus.channels.signals.RemoveChannelListener", new RemoveChannelProcessor(this));
        processors=new ProcessorMap(map);
  
        
    }
    
    Multicaster list = null;

    public void add(MethodInstancePair mip) {
        list=new Multicaster(list, mip);
    }
    public void remove(Object instance) {
        
        list.remove(instance);
    }
   
    public void send(Object theSignal) {
        list.doProcess(theSignal);
    }


    public void doProcess(Object theSignal) {
        //processors.doProcess(theSignal);
    }

    public void clear() { 
        list=null;
    }

    public Iterator iterator() {
        //not used currently.
        return null;
    }
    
    private class Multicaster implements IProcessor
    {
        private final MethodInstancePair mip;
        private final Multicaster next;
        
        public Multicaster(Multicaster next, MethodInstancePair mip)
        {
            this.mip=mip;
            this.next=next;
        }
        
        public void doProcess(Object signal)
        {
            mip.doProcess(signal);
            if(next!=null)
                next.doProcess(signal);
        }
        
        public Multicaster add(Multicaster next, MethodInstancePair mip)
        {
            
            return new Multicaster(next, mip);
        }
        
        //Remove mip processor but do it by rebuilding
        //the chain. This makes this thread safe
        //tip o the hat to the folks at Sun
        public Multicaster remove(Object instance)
        {
            if(instance==mip.instance) return next;

            Multicaster nextNext = remove(next, instance);
            if(nextNext==next)
                return this;
            else
                return add(nextNext,mip);
        }
        
        public Multicaster remove(Multicaster nextNext, Object toRemove)
        {
            if(nextNext.mip.instance==toRemove || nextNext==null)
            	return null;
            else
            	return nextNext.remove(toRemove);
        }
    }
    
    private class ChannelQueueIterator implements Iterator {
       

        public ChannelQueueIterator(MethodInstancePair tail) {
           
        }

        public boolean hasNext() {
           return false;
        }

        public Object next() {
          return null;
        }

 
        public void remove() {
            // Not used...
            
        }

    }

}