/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.workerthread;

import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.interfaces.IStoppable;
import org.werx.framework.commons.spinlock.SpinLock;
import org.werx.framework.commons.spinlock.signals.StopProcessSignal;
import org.werx.framework.workerthread.signals.IRunnableSignal;

/**
 * @author Bradlee
 *
 * WorkertThreadController is a basic plug in object
 * that listens for IRunnableSignals, processes them on
 * its private thread, and then passes the result back.
 * Later versions will allow for XML specification and
 * for mutliple parallel processes.
 * 
 */
public class WorkerThreadController implements IStoppable {

	private final SpinLock processor;


	public WorkerThreadController(SpinLock processor) {
	    this.processor=processor;
	   
		ReflectionBus.plug(this);
	}

	

    public void channel(IRunnableSignal runnableSignal) {
		
		processor.doProcess(runnableSignal);
	}

	public void channel(StopProcessSignal stopSignal) {
	  
	    processor.doProcess(stopSignal);
	    System.exit(0);
	    

	}

	//This gets called byt the top processor
    public void stop() {
        processor.stop();
        
    }

}