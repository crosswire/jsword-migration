/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package org.werx.framework.commons.spinlock;

import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.bus.channels.interfaces.IChannel;
import org.werx.framework.commons.interfaces.IProcessor;
import org.werx.framework.commons.signalqueues.SignalQueue;
import org.werx.framework.commons.spinlock.signals.NotifyStopProcessSignal;

/**
 * @author Bradlee
 *
 * SpinLock is used as the main thread segregation mechanism.
 * Focus is on thread saftety and flexibility. Signals come into
 * an instance of this class, pass onto the lockThread for processing,
 * releasing the orignal thread to return. All subsequent processing
 * is on the lockThread minimizing synchronization requirements.
 */
public class SpinLock implements Runnable, IChannel {

    private SignalQueue signalQueue = new SignalQueue();

    private Thread lockThread;

    private boolean runThread = true;

    //This is generally the ProcessorMap that is keyed
    //by signal name but may be any processor. The 
    //SwingProxy, for example, passes it's own processor in.
    private final IProcessor processor;

    public SpinLock(String name, IProcessor processor, boolean isDaemon) {
        this.processor=processor;

        lockThread = new Thread(this, name);
        lockThread.setDaemon(isDaemon);
        lockThread.start();
    }
    

    /**
     * run ()
     * 
     * This method waits for a signal by checking the signalQueue. The queue
     * size grows as pending signals are added. It removes the signal from the
     * queue and broadcasts it on the bus.
     * 
     * @param Void
     * @return Void
     * @throws InterruptedException
     *             (logged) Exception (normal and unlogged)
     * 
     *  
     */
    public void run() {
        while (runThread) {

            //The blockWhileEmpty method blocks the
            //spinlock thread as long as there aren't any
            //signals in the queue.
            signalQueue.blockWhileEmpty();

            if (runThread) {
                //run on private thread
                processor.doProcess(signalQueue.remove());

            }

        }
    }

    /**
     * Add signal to queue. Qeueue calls notify to wake up waiting private
     * thread.
     * 
     * @param theMessageToSend
     *            All signals must imlement IBusSignal
     *  
     */
    public final void doProcess(Object theMessageToSend) {

        synchronized (signalQueue) {
            signalQueue.add(theMessageToSend);
            signalQueue.notifyAll();

        }

    }

    public final void stop() {
        synchronized (signalQueue) {
            
            runThread = false;

            signalQueue.setRunning(false);

            ReflectionBus.broadcast(new NotifyStopProcessSignal(lockThread.getName()));
            signalQueue.notifyAll();
        }

    }
}