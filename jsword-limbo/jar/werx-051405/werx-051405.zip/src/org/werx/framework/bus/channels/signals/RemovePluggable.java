/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.signals;


public class RemovePluggable{
    
    private Object toRemove;
    public RemovePluggable(Object toRemove)
    {
        this.toRemove=toRemove;
    }
    
    public Object getPluggable()
    {
        return toRemove;
    }

}
