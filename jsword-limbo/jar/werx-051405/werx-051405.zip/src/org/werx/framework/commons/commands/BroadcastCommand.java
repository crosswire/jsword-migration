/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.commons.commands;

import org.werx.framework.bus.ReflectionBus;


/**
 * @author Bradlee
 *
 * 
 */
public class BroadcastCommand implements ICommand {

    Object signalToBroadcast;
    public BroadcastCommand(Object signalToBroadcast)
    {
        this.signalToBroadcast=signalToBroadcast;
    }
    public void execute() {
       
        ReflectionBus.broadcast(signalToBroadcast);

    }

}
