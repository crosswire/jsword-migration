/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.commons.spinlock.processors;

import org.werx.framework.commons.interfaces.IProcessor;
import org.werx.framework.commons.interfaces.IStoppable;
import org.werx.framework.commons.spinlock.signals.StopProcessSignal;

/**
 *  Stops and IStoppable object via messaging.
 */
public class StopProcessor implements IProcessor {

    private final String threadName;
    private final IStoppable stoppable;
    public StopProcessor(IStoppable stoppable, String threadName) {
        this.threadName=threadName;
        this.stoppable=stoppable;
    }

    public void doProcess(Object signal) {

        StopProcessSignal stopSignal = (StopProcessSignal) signal;
        if(stopSignal.getProcessName().equals(threadName))
            stoppable.stop();
    }
}

