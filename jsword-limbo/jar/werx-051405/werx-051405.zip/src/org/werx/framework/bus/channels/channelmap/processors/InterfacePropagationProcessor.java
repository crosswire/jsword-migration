/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.framework.bus.channels.channelmap.processors;

import java.util.Map;

import org.werx.framework.commons.interfaces.IProcessor;

/**
 * The InterfacePropagationProcessor is used for propagating
 * signals based on interface only. Concrete signal names
 * are not used by this processor.
 */
public class InterfacePropagationProcessor implements IProcessor {
    Map busMap;

    public InterfacePropagationProcessor(Map busMap) {
        this.busMap = busMap;
    }

    /* 
     * This method uses reflection to get the interfaces defined
     * on the signal. Those interfaces are then iterated and sent
     * to the bus map. If the bus map contains any channels for 
     * the interface the message will be propagated.
     * 
     * @see org.werx.framework.commons.interfaces.IProcessor#doProcess(java.lang.Object)
     */
    public void doProcess(Object theSignal) {
        Class[] interfaces = theSignal.getClass().getInterfaces();
      
		for (int i = 0; i < interfaces.length; i++) {
			IProcessor channel = (IProcessor) busMap.get(interfaces[i].getName());
			//System.out.println(interfaces[i].getName());
			if (channel != null) {
				
				channel.doProcess(theSignal);

			}
		}
    }

}