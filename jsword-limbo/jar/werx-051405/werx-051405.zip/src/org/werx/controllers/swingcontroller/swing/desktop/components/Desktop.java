package org.werx.controllers.swingcontroller.swing.desktop.components;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.HashMap;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;

import org.werx.controllers.swingcontroller.swing.desktop.handlers.LayerManager;
import org.werx.controllers.swingcontroller.swing.desktop.handlers.WidgetPanel;
import org.werx.controllers.swingcontroller.swing.desktop.signals.DesktopSizeSignal;
import org.werx.framework.bus.ReflectionBus;

/**
 * WERX - Java Swing RAD Framework Copyright 2002 Bradlee Johnson Released under
 * LGPL license
 * 
 * @author Bradlee Johnson
 * @created March 10, 2003
 * @version 0.1
 */

public class Desktop extends ComponentAdapter {
    //----------------------------------------------------------------------
    private JDesktopPane desktop = new JDesktopPane();

    private HashMap layerManagerMap = new HashMap();

    private WidgetPanel widgetPanel = new WidgetPanel();


    private final JFrame frame;

    /**
     * Creates a new Desktop object.
     * 
     * @param theDesktop
     *            The desktopPane to use.
     */
    public Desktop(JFrame frame) {

        frame.setContentPane(desktop);
        desktop.add(widgetPanel, JDesktopPane.DEFAULT_LAYER);
        this.frame = frame;

        desktop.addComponentListener(this);

    }

    /**
     * Gets the layerManager attribute of the Desktop object
     * 
     * @param layerToGet
     *            Description of the Parameter
     * @return The layerManager value
     */
    public LayerManager getLayerManager(Integer layerToGet) {
        LayerManager toReturn = (LayerManager) layerManagerMap.get(layerToGet);
        if (toReturn == null) {
            toReturn = new LayerManager(desktop, layerToGet);
            layerManagerMap.put((Object) layerToGet, toReturn);

        }

        return toReturn;
    }

    public void componentResized(ComponentEvent e) {
        widgetPanel.setSize(desktop.getSize());
        ReflectionBus.broadcast(new DesktopSizeSignal(desktop.getSize()));
    }
	
	public void revalidate()
	{
		desktop.revalidate();
	}
	
	public void repaint()
	{
		desktop.repaint();
	}
	
	public void addWidget(DesktopWidget w)
	{
		widgetPanel.addWidget(w);
	}

   

}

