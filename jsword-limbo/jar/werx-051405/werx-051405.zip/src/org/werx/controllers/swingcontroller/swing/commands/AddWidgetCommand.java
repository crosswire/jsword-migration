/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.commands;

import org.werx.controllers.swingcontroller.swing.desktop.components.DesktopWidget;
import org.werx.controllers.swingcontroller.swing.desktop.signals.AddDesktopWidgetSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;

/**
 * @author Bradlee
 *
 */
public class AddWidgetCommand implements ICommand {

    String label;
    String upImage;
    String downImage;
    ICommand c;
    
    public AddWidgetCommand(String label, String image, ICommand c)
    {
        this(label, image, image, c);
    }
    
    public AddWidgetCommand(String label, String upImage, String downImage, ICommand c)
    {
        this.label=label;
        this.upImage=upImage;
        this.downImage=downImage;
        this.c=c;
    }

    public void execute() {
       
        ReflectionBus.broadcast(new AddDesktopWidgetSignal(new DesktopWidget(label, upImage, downImage, c)));
    

    }

}
