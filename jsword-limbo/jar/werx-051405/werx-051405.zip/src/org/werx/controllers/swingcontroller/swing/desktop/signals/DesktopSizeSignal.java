package org.werx.controllers.swingcontroller.swing.desktop.signals;

import java.awt.Dimension;

import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.framework.bus.signals.BusSignal;

/**
 * WERX - Java Swing RAD Framework
 * Copyright 2002 Bradlee Johnson
 * Released under LGPL license
 *
 * @version 0.1
 * @author Bradlee Johnson
 */

public class DesktopSizeSignal extends BusSignal implements ISwingSignal
{
    private Dimension desktopSize;

    /**
     * Creates a new DesktopSizeSignal object.
     *
     * @param Dimension of the desktop
     */
    public DesktopSizeSignal(Dimension aDesktopSize)
    {
        desktopSize=aDesktopSize;
    }

    /**
     * getDesktopSize for current size
     *
     * @return Dimension of desktop
     */
    public Dimension getDesktopSize()
    {
        return desktopSize;
    }
}