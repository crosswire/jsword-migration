package org.werx.controllers.swingcontroller.swing.commands;

import javax.swing.JComponent;

import org.werx.controllers.swingcontroller.swing.desktop.signals.ShowDialogSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;
/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
public class DoDialogCommand implements ICommand
{
    private JComponent component;
    private ActionList list;
    private Object componentHandler;
    
    public DoDialogCommand(JComponent component, Object componentHandler, ActionList list)
    {
        this.component=component;
        this.list=list;
        this.componentHandler=componentHandler;
    }
    
    public void execute() {
       
        ShowDialogSignal signal = new ShowDialogSignal(component, componentHandler, list);
        ReflectionBus.broadcast(signal);
        
    }


}

