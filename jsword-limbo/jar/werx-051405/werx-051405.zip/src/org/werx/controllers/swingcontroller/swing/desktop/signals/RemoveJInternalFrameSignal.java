package org.werx.controllers.swingcontroller.swing.desktop.signals;

import javax.swing.JInternalFrame;

import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.framework.bus.signals.BusSignal;

/**
 * WERX - Java Swing RAD Framework
 * Copyright 2002 Bradlee Johnson
 * Released under LGPL license
 *
 * @version 0.1
 * @author Bradlee Johnson
 */

public class RemoveJInternalFrameSignal extends BusSignal implements ISwingSignal
{
    private JInternalFrame frame;

    /**
     * Creates a new RemoveJInternalFrameSignal object.
     *
     * @param theFrame The JIF to remove. From the desktop for example
     */
    public RemoveJInternalFrameSignal(JInternalFrame theFrame)
    {
        frame = theFrame;
    }

    /**
     * getFrame method returns the frame to remove
     *
     * @return JIF the JInternalFrame to remove
     */
    public JInternalFrame getFrame()
    {
        return frame;
    }
}