package org.werx.controllers.swingcontroller.swing.desktop.signals;

import javax.swing.JInternalFrame;
import javax.swing.JLayeredPane;

import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.framework.bus.signals.BusSignal;

/**
 * WERX - Java Swing RAD Framework
 * Copyright 2002 Bradlee Johnson
 * Released under LGPL license
 *
 * @version 0.1
 * @author Bradlee Johnson
 */

public class AddJInternalFrameSignal extends BusSignal implements ISwingSignal
{
    private JInternalFrame frame;
    private Integer layer = JLayeredPane.DEFAULT_LAYER;

    /**
     * Creates a new AddJInternalFrameSignal object.
     *
     * @param theFrame The JIF to add
     * @param theLayer The layer to add the JIF to
     */
    public AddJInternalFrameSignal(JInternalFrame theFrame, Integer theLayer)
    {
        frame = theFrame;
        layer = theLayer;
    }

    /**
     * Creates a new AddJInternalFrameSignal object.
     *
     * @param theFrame The JIF to add to the JLayeredPane.DEFAULT_LAYER
     */
    public AddJInternalFrameSignal(JInternalFrame theFrame)
    {
        frame = theFrame;
    }

    /**
     * getFrame method for retrieveing the JIF to add
     *
     * @return JIF to use
     */
    public JInternalFrame getFrame()
    {
        return frame;
    }

    /**
     * getLayer method to indicate what layer
     * the JIF should be added to
     *
     * @return Integer indicating the appropriate layer. See
     * the JLayeredPane documentation for values.
     */
    public Integer getLayer()
    {
        return layer;
    }
}