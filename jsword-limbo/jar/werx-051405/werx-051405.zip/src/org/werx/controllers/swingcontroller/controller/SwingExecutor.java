/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.controller;

import javax.swing.SwingUtilities;

import org.werx.framework.commons.commands.ICommand;

/**
 * @author Bradlee
 *
 */
public class SwingExecutor implements Runnable{
    ICommand command;
    
    public SwingExecutor(ICommand command)
    {
        this.command=command;
        SwingUtilities.invokeLater(this);
    }
    public void run()
    {
        command.execute();
    }

}
