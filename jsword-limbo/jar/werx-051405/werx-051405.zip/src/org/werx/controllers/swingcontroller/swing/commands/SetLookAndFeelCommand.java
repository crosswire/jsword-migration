package org.werx.controllers.swingcontroller.swing.commands;

import javax.swing.UIManager;

import org.werx.controllers.swingcontroller.signals.SetLandFSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */

public class SetLookAndFeelCommand implements ICommand
{
  
    String lf;
    public SetLookAndFeelCommand()
    {

        lf=UIManager.getSystemLookAndFeelClassName();
    }
    
    public SetLookAndFeelCommand(String lf)
    {
        this.lf=lf;
    }


    public void execute()
    {
        ReflectionBus.broadcast(new SetLandFSignal(lf));
    }
}