package org.werx.controllers.swingcontroller.processors;

import org.werx.controllers.swingcontroller.swing.desktop.components.Desktop;
import org.werx.controllers.swingcontroller.swing.desktop.handlers.LayerManager;
import org.werx.controllers.swingcontroller.swing.desktop.signals.AddJInternalFrameSignal;

public class ShowJInternalFrameProcessor  {

	private final Desktop desktop;

	public ShowJInternalFrameProcessor(Desktop desktop)
	{
		this.desktop=desktop;
	}
	

	 /**
     * doProcess(AddJInternalFrameSignal method for adding a JIF to the current
     * desktop
     * 
     * @param theSignal
     *            The signal carrying the JIF
     */
    public void doProcess(AddJInternalFrameSignal theSignal) {

        LayerManager manager = desktop.getLayerManager(theSignal.getLayer());
        manager.add(theSignal.getFrame());

    }
}