package org.werx.controllers.swingcontroller.swing.desktop.decorators;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JComponent;

/**
 * WERX - Java Swing RAD Framework
 * Copyright 2003 Bradlee Johnson
 * Released under LGPL license
 * 
 * @author     Bradlee Johnson
 * @created    January 9, 2003
 * @version    0.1
 */

public class MoveDecorator implements MouseMotionListener, MouseListener
{
	JComponent toMove;

	int currentX = 0;
	int currentY = 0;
	int offsetX;
	int offsetY;
	final int width;
	final int height;


	/**
	 *  Constructor for the MoveDecorator object
	 *
	 * @param  toMove  Description of the Parameter
	 */
	public MoveDecorator(JComponent toMove)
	{
		this.toMove = toMove;
		width = toMove.getWidth();
		height = toMove.getHeight();
		toMove.addMouseMotionListener(this);
		toMove.addMouseListener(this);

	}



	/**
	 *  Description of the Method
	 *
	 * @param  e  Description of the Parameter
	 */
	public void mouseDragged(MouseEvent e)
	{
		if (e.getModifiers() - MouseEvent.BUTTON1_MASK == 0)
		{

			currentX += e.getX() - offsetX;
			currentY += e.getY() - offsetY;

			toMove.setLocation(currentX, currentY);

		}

	}


	/**
	 *  Description of the Method
	 *
	 * @param  e  Description of the Parameter
	 */
	public void mouseMoved(MouseEvent e)
	{

	}


	/**
	 *  Description of the Method
	 *
	 * @param  e  Description of the Parameter
	 */
	public void mouseEntered(MouseEvent e) { }


	/**
	 *  Description of the Method
	 *
	 * @param  e  Description of the Parameter
	 */
	public void mouseExited(MouseEvent e) { }


	///
	/**
	 *  Description of the Method
	 *
	 * @param  e  Description of the Parameter
	 */
	public void mouseClicked(MouseEvent e) { }


	/**
	 *  Description of the Method
	 *
	 * @param  e  Description of the Parameter
	 */
	public void mousePressed(MouseEvent e)
	{
		if (e.getModifiers() - MouseEvent.BUTTON1_MASK == 0)
		{
			currentX = (int) toMove.getLocation().getX();
			currentY = (int) toMove.getLocation().getY();
			offsetX = e.getX();
			offsetY = e.getY();

		}
	}


	/**
	 *  Description of the Method
	 *
	 * @param  e  Description of the Parameter
	 */
	public void mouseReleased(MouseEvent e) { }

}
