/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.desktop.handlers;

import javax.swing.JComponent;
import javax.swing.JPanel;

import org.werx.controllers.swingcontroller.swing.desktop.components.SizeOnlyLayout;
import org.werx.controllers.swingcontroller.swing.desktop.decorators.KeepVisibleDecorator;
import org.werx.controllers.swingcontroller.swing.desktop.decorators.MoveDecorator;
import org.werx.controllers.swingcontroller.swing.desktop.decorators.RevalidateVisibleDecorator;

/**
 * @author Bradlee
 * */
public class WidgetPanel extends JPanel
	{
		private int count = 1;


		/**Constructor for the WidgetPanel object */
		public WidgetPanel()
		{
			setLayout(new SizeOnlyLayout());
			setOpaque(false);
		}


		/**
		 *  Adds a feature to the Widget attribute of the WidgetPanel object
		 *
		 *@param  widget  The feature to be added to the Widget attribute
		 */
		public void addWidget(JComponent widget)
		{
			widget.setLocation(30, (64 + 30) * count++);
			//Decorators are added here as these may later
			//be configurable.
			new MoveDecorator(widget);
			new RevalidateVisibleDecorator(widget);
			new KeepVisibleDecorator(widget);
			super.add(widget);
			super.revalidate();
			super.repaint();

		}

	}