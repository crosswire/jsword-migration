package org.werx.controllers.swingcontroller.swing.commands;

import java.awt.Window;

import org.werx.controllers.swingcontroller.signals.WindowSizeSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */

public class SetWindowSizeCommand implements ICommand
{
    //instance variables
    private Window toSize;
	public int inset = 50;
	
    /**
     * Creates a new SetWindowSizeCommand object.
     *
     * @param aComponentToSize Set the size of the component passed in.
     */
    public SetWindowSizeCommand(Window toSize)
    {
        this.toSize = toSize;
    }
    
    public SetWindowSizeCommand(Window toSize, int inset)
    {
        this.toSize = toSize;
        this.inset=inset;
    }

    /**
     * Currently defaults to 50 pixels from the edge. 
     * Objects that inherit from this command can change
     * that value.
     */
    public void execute()
    {
       ReflectionBus.broadcast(new WindowSizeSignal(toSize, inset));

        
        
    }
}