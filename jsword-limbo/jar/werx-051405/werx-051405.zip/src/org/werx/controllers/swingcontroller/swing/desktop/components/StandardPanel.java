/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.desktop.components;

import java.awt.BorderLayout;
import java.util.Iterator;

import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;

import org.werx.controllers.swingcontroller.swing.commands.ActionList;

/**
 * @author Bradlee
 *

 */
public class StandardPanel extends JPanel {
    
    private JPanel buttonPanel = new JPanel();
    public StandardPanel()
    {
        super.setLayout(new BorderLayout());
        super.add(buttonPanel, BorderLayout.SOUTH);
    }
    public void add(JComponent c)
    {
        setContentPanel(c);
    }
    public void setContentPanel(JComponent c)
    {
        super.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        super.add(c, BorderLayout.NORTH);
    }
    
    public void setButtons(ActionList list)
    {
        Iterator it = list.iterator();
        Action toAdd;
        while(it.hasNext())
            buttonPanel.add(new JButton((Action) it.next()));
    }

}
