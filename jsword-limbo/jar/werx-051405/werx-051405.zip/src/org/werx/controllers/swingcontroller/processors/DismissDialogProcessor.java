package org.werx.controllers.swingcontroller.processors;

import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;

import org.werx.controllers.swingcontroller.swing.desktop.signals.DismissDialogSignal;

public class DismissDialogProcessor  {

	private final JFrame frame;
	private final List dialogs;
	public DismissDialogProcessor(JFrame frame, List dialogs)
	{
		this.frame=frame;
		this.dialogs=dialogs;
	}
	

	  public void doProcess(DismissDialogSignal signal) {
	        if (dialogs.size() > 0) {
	            JDialog toDismiss = (JDialog) dialogs.remove(dialogs.size()-1);
	            toDismiss.hide();
	            //Help garbage collection.
	            toDismiss.removeAll();

	            
	            toDismiss.dispose();

	            if (dialogs.size() > 0) {
	                JDialog current = (JDialog) dialogs.get(dialogs.size()-1);
	                current.setModal(true);

	            }

	        }
	    }
	    
}