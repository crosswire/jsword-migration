package org.werx.controllers.swingcontroller.swing.commands;

import javax.swing.JComponent;
import javax.swing.JInternalFrame;

import org.werx.controllers.swingcontroller.swing.desktop.signals.AddJInternalFrameSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;
/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
public class DoInternalFrameCommand implements ICommand
{
    private JComponent component;
    
    public DoInternalFrameCommand(JComponent component)
    {
        this.component=component;
    }
    public void execute() {
        JInternalFrame iFrame = new JInternalFrame();
        iFrame.setContentPane(component);

        AddJInternalFrameSignal addFrameSignal = new AddJInternalFrameSignal(iFrame);
      
        ReflectionBus.broadcast(addFrameSignal);
        
    }


}

