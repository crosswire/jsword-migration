package org.werx.controllers.swingcontroller.processors;

import org.werx.controllers.swingcontroller.swing.desktop.components.Desktop;
import org.werx.controllers.swingcontroller.swing.desktop.signals.AddDesktopWidgetSignal;

public class AddDesktopWidgetProcessor  {

	private final Desktop desktop;

	public AddDesktopWidgetProcessor(Desktop desktop)
	{
		this.desktop=desktop;
	}
	

    /**
     * Add a widget to the desktop.
     * 
     * @param theSignal
     *            Description of the Parameter
     */
    public void doProcess(AddDesktopWidgetSignal theSignal) {

        desktop.addWidget(theSignal.getWidget());

    }
}