package org.werx.controllers.swingcontroller.swing.desktop.decorators;

import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JComponent;

/**
 * WERX - Java Swing RAD Framework
 * Copyright 2003 Bradlee Johnson
 * Released under LGPL license
 * 
 *@author     Bradlee Johnson
 *@created    March 21, 2003
 *@version    0.1
 */

public class KeepVisibleDecorator extends MouseAdapter implements ComponentListener, MouseListener
{
	JComponent movableComponent;



	/**
	 *Constructor for the KeepVisibleDecorator object
	 *
	 *@param  movableComponent  Description of the Parameter
	 */
	public KeepVisibleDecorator(JComponent movableComponent)
	{
		this.movableComponent = movableComponent;
		movableComponent.addComponentListener(this);
		movableComponent.addMouseListener(this);

	}


	/**
	 *  Description of the Method
	 *
	 *@param  e  Description of the Parameter
	 */
	public void mouseReleased(MouseEvent e)
	{
		doBounding();
	}


	/**
	 *  Description of the Method
	 *
	 *@param  e  Description of the Parameter
	 */
	public void componentHidden(ComponentEvent e)
	{

	}


	/**
	 *  Description of the Method
	 *
	 *@param  e  Description of the Parameter
	 */
	public void componentMoved(ComponentEvent e)
	{

	}


	/**
	 *  Description of the Method
	 *
	 *@param  e  Description of the Parameter
	 */
	public void componentResized(ComponentEvent e)
	{
		doBounding();
	}


	/**
	 *  Description of the Method
	 *
	 *@param  e  Description of the Parameter
	 */
	public void componentShown(ComponentEvent e)
	{
		doBounding();
	}


	/**  Description of the Method */
	private void doBounding()
	{

		Rectangle cb = movableComponent.getBounds();
		Rectangle cbParent = movableComponent.getParent().getBounds();

		if (cb.x + cb.width >= cbParent.width)
		{
			int currentX = cbParent.width - cb.width;
			movableComponent.setLocation(currentX, movableComponent.getY());
		}

		if (cb.y + cb.height >= cbParent.height)
		{
			int currentY = cbParent.height - cb.height;
			movableComponent.setLocation(movableComponent.getX(), currentY);
		}

		if (cb.x < cbParent.x)
		{

			movableComponent.setLocation(cbParent.x + 1, movableComponent.getY());
		}

		if (cb.y < cbParent.y)
		{
			movableComponent.setLocation(movableComponent.getX(), cbParent.y + 1);
		}
	}

}
