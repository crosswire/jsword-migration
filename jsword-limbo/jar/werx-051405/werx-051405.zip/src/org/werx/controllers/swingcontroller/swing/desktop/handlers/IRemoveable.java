/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.desktop.handlers;

/**
 * @author Bradlee
 *
 */
public interface IRemoveable {

    public void remove();
}
