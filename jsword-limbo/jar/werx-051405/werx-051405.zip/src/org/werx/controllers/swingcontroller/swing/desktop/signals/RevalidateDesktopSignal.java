package org.werx.controllers.swingcontroller.swing.desktop.signals;

import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.framework.bus.signals.BusSignal;

/**
 * WERX - Java Swing RAD Framework
 * Copyright 2002 Bradlee Johnson
 * Released under LGPL license
 *
 *@author     Bradlee Johnson
 *@created    March 18, 2003
 *@version    0.1
 */

public class RevalidateDesktopSignal extends BusSignal implements ISwingSignal
{

}

