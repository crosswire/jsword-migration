package org.werx.controllers.swingcontroller.signals;

public interface ISwingSignal {

}
