package org.werx.controllers.swingcontroller.swing.commands;

import javax.swing.JFrame;

import org.werx.controllers.swingcontroller.swing.imagecontroller.signals.GetImageIconsSignal;
import org.werx.controllers.swingcontroller.swing.imagecontroller.signals.ReturnImageIconsSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */

public class SetFrameTitleCommand implements ICommand
{
    JFrame frame;
    String title;
    String imageName;

    public SetFrameTitleCommand(JFrame toInitialize, String title)
    {
        this(toInitialize,title,null);
    }
    
    public SetFrameTitleCommand(JFrame toInitialize, String title, String img)
    {
        frame = toInitialize;
        this.title=title;
        this.imageName=img;
        if(imageName!=null)
        {
            ReflectionBus.plug(this);
            ReflectionBus.broadcast(new GetImageIconsSignal(this, imageName));
      
        }
    }

    /**
     * The object is set visible and then packed if necessary.
     */
    public void execute()
    {
        frame.setTitle(title);
       
    }
    
    public void channel(ReturnImageIconsSignal signal)
	{
 
        if(signal.isMyAddress(this))
        {
            ReflectionBus.unplug(this);
           
            frame.setIconImage(signal.getImageIcon(imageName).getImage());
        }
    }
}