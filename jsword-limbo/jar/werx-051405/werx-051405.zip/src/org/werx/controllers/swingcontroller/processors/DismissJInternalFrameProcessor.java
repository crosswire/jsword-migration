package org.werx.controllers.swingcontroller.processors;

import javax.swing.JDesktopPane;

import org.werx.controllers.swingcontroller.swing.desktop.components.Desktop;
import org.werx.controllers.swingcontroller.swing.desktop.signals.RemoveJInternalFrameSignal;

public class DismissJInternalFrameProcessor  {

	private final Desktop desktop;

	public DismissJInternalFrameProcessor(Desktop desktop)
	{
		this.desktop=desktop;
	}
	

    /**
     * doProcess(RemoveJInternalFrameSignal method for removing a JIF from the
     * current desktop
     * 
     * @param theSignal
     */
    public void doProcess(RemoveJInternalFrameSignal theSignal) {
        RemoveJInternalFrameSignal message = (RemoveJInternalFrameSignal) theSignal;

        Integer theLayerNumber = new Integer(JDesktopPane.getLayer(message
                .getFrame()));

        desktop.getLayerManager(theLayerNumber).remove(message.getFrame());

    }
}