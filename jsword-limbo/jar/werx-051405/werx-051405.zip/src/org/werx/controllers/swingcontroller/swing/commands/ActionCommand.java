package org.werx.controllers.swingcontroller.swing.commands;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;

import org.werx.framework.commons.commands.ICommand;
/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
public class ActionCommand extends AbstractAction 
{
	ICommand command;


	/**
	 *Constructor for the ActionCommand object
	 *
	 *@param  address     Description of the Parameter
	 *@param  label       Description of the Parameter
	 *@param  theCommand  Description of the Parameter
	 */
	public ActionCommand(String label, ICommand theCommand)
	{
		
		super.putValue(Action.NAME, label);
		command = theCommand;
		
	}



	/**
	 * When this command is fire it executes the command object.
	 *
	 *@param  e  Description of the Parameter
	 */
	public void actionPerformed(ActionEvent e)
	{
		command.execute();

	}


	/**
	 *  Sets the command attribute of the ActionCommand object
	 *
	 *@param  command  The new command value
	 */
	public void setCommand(ICommand command)
	{
		this.command = command;
	}


}

