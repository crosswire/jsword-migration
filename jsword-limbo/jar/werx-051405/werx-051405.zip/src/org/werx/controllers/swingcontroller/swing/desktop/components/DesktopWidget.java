package org.werx.controllers.swingcontroller.swing.desktop.components;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import org.werx.controllers.swingcontroller.swing.imagecontroller.signals.GetImageIconsSignal;
import org.werx.controllers.swingcontroller.swing.imagecontroller.signals.ReturnImageIconsSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;

/**
 * WERX - Java Swing RAD Framework Copyright 2005 Bradlee Johnson 
 * Released under LGPL license
 * 
 * @author Bradlee Johnson
 * @created May 16, 2005
 * @version 2.1
 */

public class DesktopWidget extends JLabel implements MouseListener {

    ICommand command;
    ImageIcon up;
    ImageIcon down;
    String iconUpName;
    String iconDownName;
    


    public DesktopWidget(String label, String iconUpName, String iconDownName,ICommand command) {
        setLabel(label);
        this.command = command;
        this.iconUpName=iconUpName;
        this.iconDownName=iconDownName;
        ReflectionBus.plug(this);
	    ReflectionBus.broadcast(new GetImageIconsSignal(this,new String[]{iconUpName,iconDownName}));
	  
    }
    
    public void channel(ReturnImageIconsSignal signal)
    {
        this.up=signal.getImageIcon(iconUpName);
        this.down=signal.getImageIcon(iconDownName);
     
        super.setIcon(up);
        ReflectionBus.unplug(this);
        super.addMouseListener(this);
        revalidate();
        repaint();
    }
    
    /**
     * Sets the label attribute of the DesktopWidget object
     * 
     * @param myLabel
     *            The new label value
     */
    public void setLabel(String myLabel) {
        super.setVerticalTextPosition(SwingConstants.BOTTOM);
        super.setHorizontalTextPosition(SwingConstants.CENTER);
        super.setText(myLabel);
    }

    /**
     * Description of the Method
     * 
     * @param e
     *            Description of the Parameter
     */
    public void mouseClicked(MouseEvent e) {
        if (command != null)
            command.execute();
        super.setIcon(up);
    }

    /**
     * Description of the Method
     * 
     * @param e
     *            Description of the Parameter
     */
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * Description of the Method
     * 
     * @param e
     *            Description of the Parameter
     */
    public void mouseExited(MouseEvent e) {
        super.setIcon(up);
    }

    /**
     * Description of the Method
     * 
     * @param e
     *            Description of the Parameter
     */
    public void mousePressed(MouseEvent e) {
        super.setIcon(down);
    }

    /**
     * Description of the Method
     * 
     * @param e
     *            Description of the Parameter
     */
    public void mouseReleased(MouseEvent e) {
        super.setIcon(up);
    }

}

