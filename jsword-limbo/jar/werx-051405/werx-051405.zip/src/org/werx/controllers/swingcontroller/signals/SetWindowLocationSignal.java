/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.signals;

import java.awt.Window;


/**
 * @author Bradlee
 *
 */
public class SetWindowLocationSignal implements ISwingSignal {
    
	public static final String CENTER = "center";
	public static final String BOTTOM = "bottom";
    public final String xLocation;
    public final String yLocation;
    public final Window window;
	
    public SetWindowLocationSignal(Window w, String xLocation, String yLocation)
    {
        this.window=w;
        this.xLocation=xLocation;
        this.yLocation=yLocation;
    }
}
