package org.werx.controllers.swingcontroller.processors;

import org.werx.controllers.swingcontroller.swing.desktop.components.Desktop;
import org.werx.controllers.swingcontroller.swing.desktop.signals.RevalidateDesktopSignal;

public class RevalidateDesktopProcessor  {

	private final Desktop desktop;

	public RevalidateDesktopProcessor(Desktop desktop)
	{
		this.desktop=desktop;
	}
	

    /**
     * Something changed so revalidate the components.
     * 
     * @param theSignal
     *            Description of the Parameter
     */
    public void doProcess(RevalidateDesktopSignal theSignal) {

        desktop.revalidate();
        desktop.repaint();
    }
}