/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.processors;

import java.awt.Dimension;
import java.awt.Toolkit;

import org.werx.controllers.swingcontroller.signals.SetWindowLocationSignal;
import org.werx.controllers.swingcontroller.swing.commands.ComponentLocationCalculator;

/**
 * @author Bradlee
 */
public class WindowLocationProcessor {

	public WindowLocationProcessor() {
		
	}

	public void doProcess(SetWindowLocationSignal signal) {
		int x = 0;
		int y = 0;
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

		// xCalcs...
		if (signal.xLocation.equals("CENTER")) {
			x = calculateCenteredXLocation(signal, screenSize);
		}

		// yCalcs...
		if (signal.yLocation.equals("CENTER")) {
			y = calculateCenteredYLocation(signal, screenSize);
		} else if (signal.yLocation.equals(ComponentLocationCalculator.BOTTOM)) {
			y = calculateBottomYLocation(signal, screenSize);
		}
		
		signal.window.setLocation(x, y);
	}

	private int calculateCenteredXLocation(SetWindowLocationSignal signal,Dimension screensize) {
		return (screensize.width - signal.window.getWidth()) / 2;
	}

	private int calculateCenteredYLocation(SetWindowLocationSignal signal,Dimension screensize) {
		return (screensize.height - signal.window.getHeight()) / 2;
	}

	private int calculateBottomYLocation(SetWindowLocationSignal signal,Dimension screensize) {
		return screensize.height - signal.window.getHeight();
	}
}
