/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Nathan Slippen
 * @created on Apr 29, 2005 , 2005
 * @version Version2.1
 *   
 */


package org.werx.controllers.filecontroller.file.signals;


import org.werx.framework.bus.signals.BusSignal;


/*
 * @author Nathan
 */

public class FileErrorSignal extends BusSignal implements IFileSignal
{


public final String title;
public final String errorMessage;
public final Exception e;
private Object requestor;


public FileErrorSignal(Object requestor, String title, String errorMessage, Exception e)
{
   this.requestor = requestor;
   this.title=title;
   this.errorMessage=errorMessage;
   this.e=e;
}


/**
 *  Gets the requestor attribute of the OpenFileSignal object
 *
 *@return    The requestor value
 */
public Object getRequestor() {
	return requestor;
}

}


