/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.commands;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.swing.Action;


/**
 * @author Bradlee List command that aggregates other commands.
 */
public class ActionList  {

    private List list;
    public ActionList(List list)
    {
        this.list=list;
    }
	
	public ActionList()
	{
		list=new LinkedList();
	}

    public void addAction(Action toAdd)
    {
        list.add(toAdd);
        
    }
    
    public Iterator iterator()
    {
        return list.iterator();
    }
 
}