package org.werx.controllers.swingcontroller.swing.desktop.signals;

import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.controllers.swingcontroller.swing.desktop.components.DesktopWidget;
import org.werx.framework.bus.signals.BusSignal;

/**
 * WERX - Java Swing RAD Framework
 * Copyright 2002 Bradlee Johnson
 * Released under LGPL license
 *
 *@author     Bradlee Johnson
 *@created    March 18, 2003
 *@version    0.1
 */

public class AddDesktopWidgetSignal extends BusSignal implements ISwingSignal
{
	private DesktopWidget widget;



	/**
	 *Constructor for the AddDesktopWidgetSignal object
	 *
	 *@param  widget  Description of the Parameter
	 */
	public AddDesktopWidgetSignal(DesktopWidget widget)
	{
		this.widget = widget;
	}



	/**
	 * getFrame method for retrieveing the JIF to add
	 *
	 *@return    JIF to use
	 */
	public DesktopWidget getWidget()
	{
		return widget;
	}

}
