/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Nathan Slippen
 * @created on Apr 29, 2005 , 2005
 * @version Version2.1
 *   
 */


package org.werx.controllers.filecontroller.file.controller;


import java.util.HashMap;

import org.werx.controllers.filecontroller.file.signals.IFileSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.controllers.AbstractController;




/*
 * @author Nathan
 */

public class FileController extends AbstractController{

		
		
		public FileController() {
			super(new HashMap());
			ReflectionBus.plug(this);
			
		}

		public void channel(IFileSignal signal) {
			
			super.doProcess(signal);

	} // channelchannel(IFileSignal signal)

} // class FileController


