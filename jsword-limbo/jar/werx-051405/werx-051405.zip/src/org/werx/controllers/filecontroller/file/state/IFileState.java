/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Nathan Slippen
 * @created on Apr 30, 2005 , 2005
 * @version Version2.1
 *   
 */


package org.werx.controllers.filecontroller.file.state;


import org.werx.controllers.filecontroller.file.signals.CloseFileSignal;
import org.werx.controllers.filecontroller.file.signals.FileReadSignal;
import org.werx.controllers.filecontroller.file.signals.OpenFileSignal;


/*
 * @author Nathan
 */

public interface IFileState {

    
    
    
	/**
	 *  Description of the Method
	 *
	 *@param  theSignal  Description of the Parameter
	 */
	public void open(OpenFileSignal theSignal);


	/**
	 *  Description of the Method
	 *
	 *@param  theSignal  Description of the Parameter
	 */
	public void close(CloseFileSignal theSignal);


	/**
	 *  Description of the Method
	 *
	 *@param  theSignal  Description of the Parameter
	 */
	public void read(FileReadSignal theSignal);


	/**
	 *  Description of the Method
	 *
	 *@param  theSignal  Description of the Parameter
	 */
	///public void write(FileWriteSignal theSignal);
    
    
}



