/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Nathan Slippen
 * @created on May 9, 2005 , 2005
 * @version Version2.1
 *   
 */


package org.werx.controllers.filecontroller.file.signals;
/*
 * @author Nathan
 */

public interface IFileSignal {

}



