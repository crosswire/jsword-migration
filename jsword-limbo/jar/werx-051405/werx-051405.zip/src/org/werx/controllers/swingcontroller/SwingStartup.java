package org.werx.controllers.swingcontroller;

import org.werx.controllers.swingcontroller.controller.SwingHandlerController;
import org.werx.controllers.swingcontroller.swing.commands.AddWindowObserverCommand;
import org.werx.controllers.swingcontroller.swing.commands.ExitCommand;
import org.werx.controllers.swingcontroller.swing.commands.SetFrameTitleCommand;
import org.werx.controllers.swingcontroller.swing.commands.SetLookAndFeelCommand;
import org.werx.controllers.swingcontroller.swing.commands.SetVisibleCommand;
import org.werx.controllers.swingcontroller.swing.commands.SetWindowSizeCommand;
import org.werx.controllers.swingcontroller.swing.imagecontroller.ImageLibraryController;

public class SwingStartup {

	public SwingStartup() {
		new ImageLibraryController("lib/images.jar");
		javax.swing.JFrame frame = new javax.swing.JFrame();
		new StartSwingProcessors(frame);
		new SwingHandlerController();

		
		
		new SetFrameTitleCommand(frame, "Werx2 Framework", "Werx.gif")
				.execute();

		new SetLookAndFeelCommand().execute();
		new SetVisibleCommand(frame).execute();
		new SetWindowSizeCommand(frame).execute();
		new AddWindowObserverCommand("CLOSING", new ExitCommand(), frame)
				.execute();

	}

}
