package org.werx.controllers.swingcontroller.swing.desktop.signals;

import javax.swing.JComponent;

import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.controllers.swingcontroller.swing.commands.ActionList;
import org.werx.framework.bus.signals.BusSignal;

/**
 * WERX - Java Swing RAD Framework
 * Copyright 2002 Bradlee Johnson
 * Released under LGPL license
 *
 * @version 0.1
 * @author Bradlee Johnson
 */

public class ShowDialogSignal extends BusSignal implements ISwingSignal
{
    JComponent component;
    String title = "Unset title....";
    ActionList actionList=null;
    Object componentHandler;


    public ShowDialogSignal(JComponent toShow, Object componentHandler, ActionList list)
    {
        component = toShow;
        this.actionList=list;
        this.componentHandler=componentHandler;
    }

    /**
     * getComponent method used by the dialog
     * to retrieve the compent to show.
     *
     * @return JComponent to show
     */
    public JComponent getComponent()
    {
        return component;
    }
    
    public ActionList getActionList()
    {
        return actionList;
    }
    
    public Object getHandler()
    {
        return this.componentHandler;
    }

    /**
     * getTitle method used by the dialog to 
     * fetch a title to use.
     *
     * @return String used for the title of the dialog
     */
    public String getTitle()
    {
        return title;
    }

    /**
     * setTitle method used by sender to indicate
     * the title to use.
     *
     * @param toDisplay String to use for a title
     */
    public void setTitle(String toDisplay)
    {
        title = toDisplay;
    }
    
    
}