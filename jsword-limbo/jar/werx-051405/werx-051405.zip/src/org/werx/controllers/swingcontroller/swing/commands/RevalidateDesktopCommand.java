/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.commands;

import org.werx.controllers.swingcontroller.swing.desktop.signals.RevalidateDesktopSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;

/**
 * @author Bradlee
 *
 */
public class RevalidateDesktopCommand implements ICommand {

    

    public void execute() {
       ReflectionBus.broadcast(new RevalidateDesktopSignal());
        
    }

}
