package org.werx.controllers.swingcontroller.processors;

import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import org.werx.controllers.swingcontroller.swing.commands.SetWindowLocationCommand;
import org.werx.controllers.swingcontroller.swing.desktop.components.StandardPanel;
import org.werx.controllers.swingcontroller.swing.desktop.signals.DismissDialogSignal;
import org.werx.controllers.swingcontroller.swing.desktop.signals.ShowDialogSignal;
import org.werx.controllers.swingcontroller.swing.observers.WindowObserver;
import org.werx.framework.commons.commands.BroadcastCommand;

public class ShowDialogProcessor  {

	private final JFrame frame;
	private final List dialogs;
	public ShowDialogProcessor(JFrame frame, List dialogs)
	{
		this.frame=frame;
		this.dialogs=dialogs;
	}
	

    public void doProcess(ShowDialogSignal signal) {
      
        JDialog d = new JDialog(frame);
        d.setDefaultCloseOperation(d.DO_NOTHING_ON_CLOSE);
        d.setModal(true);
       

        WindowObserver wo=new WindowObserver(d);
        
        wo.setCommand(WindowObserver.CLOSING, new BroadcastCommand(new DismissDialogSignal()));
        if (dialogs.size() > 0) {
            JDialog currentDialog = (JDialog) dialogs.get(dialogs.size());
            currentDialog.setModal(false);
        }
        dialogs.add(d);
        StandardPanel p = new StandardPanel();
        
        p.setContentPanel(signal.getComponent());
        p.setButtons(signal.getActionList());
        d.getContentPane().add(p);

        d.pack();
       
        new SetWindowLocationCommand(d,"CENTER","CENTER").execute();
       

        //Make sure that look and feel is picked up...
        SwingUtilities.updateComponentTreeUI(d);
        
        d.show();
    }
}