/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.garbagecontroller;

import org.werx.controllers.garbagecontroller.signals.GarbageCycleSignal;
import org.werx.framework.bus.IBus;

/**
 * Garbage Collector is pluggable component that does simple count of messages
 * and then makes gc request
 */
public class GarbageController {
	private static GarbageController controller;

	//Every cycleRate number of bus signals, fire the GC.
	private int cycleRate = 40;

	private int counter = 0;

	public GarbageController(IBus bus) {
		bus.plug(this);
	}

	/**
	 * Counts bus signals and makes gc requests after cycle rate is reached.
	 */
	public void channel(Object theSignal) {
		counter++;

		if (cycleRate < counter) {
			counter = 0;
			System.runFinalization();
			System.gc();

		}
	}

	/**
	 * Message to set the cycle rate.
	 */
	public void channel(GarbageCycleSignal theSignal) {
		this.cycleRate = theSignal.getCycleRate();
	}
}