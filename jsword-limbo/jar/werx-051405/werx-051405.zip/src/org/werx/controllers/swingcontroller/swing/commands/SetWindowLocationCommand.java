package org.werx.controllers.swingcontroller.swing.commands;

import java.awt.Window;

import org.werx.controllers.swingcontroller.signals.SetWindowLocationSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */

public class SetWindowLocationCommand implements ICommand
{
   
    private final String xLocation;
    private final String yLocation;
	private final Window w;

    /**
     * Creates a new SetComponentLocationCommand object.
     *
     * @param toLocate The component to be located on the screen
     * @param theLocation The String value of the location defined by class constants
     */
    public SetWindowLocationCommand(Window w,String horizontal, String vertical)
    {
		this.w=w;
        yLocation = vertical;
        xLocation = horizontal;
    }

    /**
     * Calculate the location of the upper left x,y based on specified location.
     */
    public void execute()
    {
       


        //set the location...
        ReflectionBus.broadcast(new SetWindowLocationSignal(w,xLocation,yLocation));

    }


  
}