package org.werx.controllers.swingcontroller.controller;
/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.SwingUtilities;

import org.werx.controllers.swingcontroller.signals.AddSwingHandlerSignal;
import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.processors.MethodInstancePair;

public class SwingHandlerController implements ComponentListener  {
	
	LinkedList handlers = new LinkedList();
	public SwingHandlerController()
	{
		
		ReflectionBus.plug(this);
	}
	
	public void channel(AddSwingHandlerSignal signal)
	{
		
		handlers.add(new HandlerMap(signal));
		signal.component.addComponentListener(this);
		
	}
	
	
	public void channel(final ISwingSignal signal)
	{
		Object[] handlerArr=null;
		synchronized(handlers)
		{
			handlerArr=handlers.toArray();
		}
		
		if(handlerArr!=null)
		{

					
			for (int i=0;i<handlerArr.length;i++)
			{
				HandlerMap map = (HandlerMap) handlerArr[i];
				map.doProcess(signal);
			}
				
		}
	}

	public void componentResized(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void componentShown(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void componentHidden(ComponentEvent e) {
		HandlerMap[] handlerArr =(HandlerMap[]) handlers.toArray();
		for(int i=0;i<handlerArr.length;i++)
		{
			if(handlerArr[i].signal.component==e.getSource())
			{
				handlerArr[i].signal.component.removeComponentListener(this);
				handlers.remove(handlerArr[i]);
				
			}
		}
		
	}
	
	private class HandlerMap extends HashMap implements ComponentListener
	{
		AddSwingHandlerSignal signal;
		public HandlerMap(AddSwingHandlerSignal signal)
		{
			this.signal=signal;
			
			Method[] methods =signal.handler.getClass().getMethods();
			
			for (int i=0;i<methods.length;i++)
			{
				Method m=methods[i];
				if (m.getName().equals("doProcess") && m.getParameterTypes().length==1)
				{
					//System.out.println("doProcess:"+m.getParameterTypes()[0].getName());
					MethodInstancePair mip = new MethodInstancePair(m,signal.handler);
					super.put(m.getParameterTypes()[0],mip);
				}
				
			}
		}
		
		public void doProcess(Object signal)
		{
			MethodInstancePair mip = (MethodInstancePair) super.get(signal.getClass());
			if(mip!=null)
			{
				SwingUtilities.invokeLater(new SwingMIPRunnable(mip,signal));
			}
		}
		
		public void remove()
		{
			super.clear();
			signal.component.removeComponentListener(this);
			
		}

		public void componentResized(ComponentEvent e) {
			// TODO Auto-generated method stub
			
		}

		public void componentMoved(ComponentEvent e) {
			// TODO Auto-generated method stub
			
		}

		public void componentShown(ComponentEvent e) {
			// TODO Auto-generated method stub
			
		}

		public void componentHidden(ComponentEvent e) {
			remove();
			
		}
	}




}
