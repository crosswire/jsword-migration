/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.signals;

import java.awt.Window;

/**
 * @author Bradlee
 *
 */
public class ShowWindowSignal implements ISwingSignal {

    public final Window init;


    public ShowWindowSignal(Window toInitialize)
    {
        init = toInitialize;
    }
}
