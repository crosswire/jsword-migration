package org.werx.controllers.swingcontroller.swing.commands;

import java.awt.Window;

import org.werx.controllers.swingcontroller.signals.ShowWindowSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.commands.ICommand;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */

public class ShowWindowCommand implements ICommand
{
    Window init;


    public ShowWindowCommand(Window toInitialize)
    {
        init = toInitialize;
    }

    /**
     * The object is set visible and then packed if necessary.
     */
    public void execute()
    {
       ReflectionBus.broadcast(new ShowWindowSignal(init));
    }
}