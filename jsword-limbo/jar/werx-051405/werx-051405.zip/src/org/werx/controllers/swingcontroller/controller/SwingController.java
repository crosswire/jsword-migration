package org.werx.controllers.swingcontroller.controller;

import java.lang.reflect.Method;
import java.util.HashMap;

import javax.swing.SwingUtilities;

import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.processors.MethodInstancePair;
import org.werx.framework.commons.processors.MethodInstancePairRunner;

public class SwingController {
	
	HashMap controllerMap = new HashMap();
	public SwingController() {
		
		ReflectionBus.plug(this);
		
	}
	
	public void setProcessor(Class signal, Object processor)
	{
		try {
			Method m=processor.getClass().getMethod("doProcess",new Class[]{signal});
			
			controllerMap.put(signal.getName(),new MethodInstancePair(m,processor));
			
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void channel(ISwingSignal signal) {

		MethodInstancePair mip=(MethodInstancePair)controllerMap.get(signal.getClass().getName());

		if(mip!=null)
		{
			
			SwingUtilities.invokeLater(new MethodInstancePairRunner(mip,signal));
			
		}
	}
	
	
	
	

}
