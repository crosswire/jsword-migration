package org.werx.controllers.swingcontroller;

import java.util.LinkedList;

import javax.swing.JFrame;

import org.werx.controllers.swingcontroller.controller.SwingController;
import org.werx.controllers.swingcontroller.processors.AddDesktopWidgetProcessor;
import org.werx.controllers.swingcontroller.processors.DismissDialogProcessor;
import org.werx.controllers.swingcontroller.processors.DismissJInternalFrameProcessor;
import org.werx.controllers.swingcontroller.processors.LandFProcessor;
import org.werx.controllers.swingcontroller.processors.RevalidateDesktopProcessor;
import org.werx.controllers.swingcontroller.processors.SetCursorProcessor;
import org.werx.controllers.swingcontroller.processors.ShowDialogProcessor;
import org.werx.controllers.swingcontroller.processors.ShowErrorDialogProcessor;
import org.werx.controllers.swingcontroller.processors.ShowJInternalFrameProcessor;
import org.werx.controllers.swingcontroller.processors.ShowWindowProcessor;
import org.werx.controllers.swingcontroller.processors.WindowLocationProcessor;
import org.werx.controllers.swingcontroller.processors.WindowSizeProcessor;
import org.werx.controllers.swingcontroller.signals.SetCursorSignal;
import org.werx.controllers.swingcontroller.signals.SetLandFSignal;
import org.werx.controllers.swingcontroller.signals.SetWindowLocationSignal;
import org.werx.controllers.swingcontroller.signals.ShowWindowSignal;
import org.werx.controllers.swingcontroller.signals.WindowSizeSignal;
import org.werx.controllers.swingcontroller.swing.desktop.components.Desktop;
import org.werx.controllers.swingcontroller.swing.desktop.signals.AddDesktopWidgetSignal;
import org.werx.controllers.swingcontroller.swing.desktop.signals.AddJInternalFrameSignal;
import org.werx.controllers.swingcontroller.swing.desktop.signals.DismissDialogSignal;
import org.werx.controllers.swingcontroller.swing.desktop.signals.RemoveJInternalFrameSignal;
import org.werx.controllers.swingcontroller.swing.desktop.signals.RevalidateDesktopSignal;
import org.werx.controllers.swingcontroller.swing.desktop.signals.ShowDialogSignal;
import org.werx.controllers.swingcontroller.swing.desktop.signals.ShowErrorSignal;

public class StartSwingProcessors {
	public StartSwingProcessors(JFrame frame) {
		SwingController controller = new SwingController();
		
		LinkedList dialogList = new LinkedList();
		Desktop desktop = new Desktop(frame);
		
		controller.setProcessor(ShowWindowSignal.class, new ShowWindowProcessor());
		controller.setProcessor(WindowSizeSignal.class, new WindowSizeProcessor());
		controller.setProcessor(SetWindowLocationSignal.class, new WindowLocationProcessor());
		controller.setProcessor(SetLandFSignal.class, new LandFProcessor());
		
		
		
		controller.setProcessor(ShowDialogSignal.class, new ShowDialogProcessor(frame,dialogList));
		controller.setProcessor(DismissDialogSignal.class, new DismissDialogProcessor(frame,dialogList));
		controller.setProcessor(SetCursorSignal.class, new  SetCursorProcessor(frame));
		controller.setProcessor(ShowErrorSignal.class, new ShowErrorDialogProcessor(frame));
		
		controller.setProcessor(AddJInternalFrameSignal.class, new ShowJInternalFrameProcessor(desktop));
		controller.setProcessor(RemoveJInternalFrameSignal.class, new DismissJInternalFrameProcessor(desktop));
		controller.setProcessor(RevalidateDesktopSignal.class, new RevalidateDesktopProcessor(desktop));
		controller.setProcessor(AddDesktopWidgetSignal.class, new AddDesktopWidgetProcessor(desktop));
		
	}

}
