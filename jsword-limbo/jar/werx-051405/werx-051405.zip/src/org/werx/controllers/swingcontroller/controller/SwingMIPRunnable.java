/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.controller;

import org.werx.framework.commons.processors.MethodInstancePair;


class SwingMIPRunnable implements Runnable
{
    private final MethodInstancePair pair;
    private final Object signal;
    
    public SwingMIPRunnable(MethodInstancePair pair,Object signal)
    {
        this.pair=pair;
        this.signal=signal;
    }
    

    public void run()
    {
        pair.doProcess(signal);
    }
}