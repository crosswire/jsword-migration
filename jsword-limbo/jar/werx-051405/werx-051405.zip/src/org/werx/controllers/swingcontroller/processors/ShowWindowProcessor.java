/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.processors;

import org.werx.controllers.swingcontroller.signals.ShowWindowSignal;

/**
 * @author Bradlee
 *
 */
public class ShowWindowProcessor  {
    
	
    
    public void doProcess(ShowWindowSignal signal)
    {
		signal.init.show();
    }
}
