/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.processors;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.werx.controllers.swingcontroller.signals.SetLandFSignal;

/**
 * @author Bradlee
 *
 */
public class LandFProcessor {
    
    public LandFProcessor()
    {
    	
    }
    //Method is protected as it is invoked from super class.
    public void doProcess(SetLandFSignal signal)
    {
        try {
            UIManager.setLookAndFeel(signal.landF);
           
           
        } catch (Exception e) { 
            //If the landf sent is illegal then just use system look and feel.
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (ClassNotFoundException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            } catch (InstantiationException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            } catch (IllegalAccessException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            } catch (UnsupportedLookAndFeelException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }
    }
}
