/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.observers;

import java.awt.Window;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.HashMap;
import java.util.Map;

import org.werx.framework.commons.commands.ICommand;

/**
 * @author Bradlee
 *
 * 
 */
public class WindowObserver implements WindowListener {

    
    Map commandMap = new HashMap();
    public static final String ACTIVATED="ACTIVATED";
    public static final String OPENING="OPENING";
    public static final String OPENED="OPENED";
    public static final String CLOSING="CLOSING";
    public static final String CLOSED="CLOSED";
    Window window;
    
    
    public WindowObserver(Window w)
    {
        this.window=w;
        w.addWindowListener(this);
       
    }
    
    public void setCommand(String cmdName, ICommand cmd)
    {
        commandMap.put(cmdName, cmd);
    }
    private void fireCommand(String cmdName)
    {
        ICommand cmd = (ICommand) commandMap.get(cmdName);
        
        if(cmd!=null)
            cmd.execute();
       
    }

    public void windowActivated(WindowEvent e) {
       
        fireCommand(ACTIVATED);
        
    }

   
    public void windowClosed(WindowEvent e) {
        fireCommand(CLOSED);
        window.removeWindowListener(this);
       // System.out.println(commandMap.get(CLOSED));
        System.gc();
    }
    /* 
     *  Remove this window listener from the closing window.
     *  Fire the associated command, if any, then call gc.
     */
    public void windowClosing(WindowEvent e) {
       // System.out.println(commandMap.get(CLOSING));
        fireCommand(CLOSING);
        
        
    }

    /* (non-Javadoc)
     * @see java.awt.event.WindowListener#windowDeactivated(java.awt.event.WindowEvent)
     */
    public void windowDeactivated(WindowEvent e) {
       
        
    }

    /* (non-Javadoc)
     * @see java.awt.event.WindowListener#windowDeiconified(java.awt.event.WindowEvent)
     */
    public void windowDeiconified(WindowEvent e) {
       
        
    }

    /* (non-Javadoc)
     * @see java.awt.event.WindowListener#windowIconified(java.awt.event.WindowEvent)
     */
    public void windowIconified(WindowEvent e) {
        
        
    }

    /* 
     * After the window is openned it can be moved to correct location
     */
    public void windowOpened(WindowEvent e) {
       fireCommand(OPENING);
    }
    

}
