package org.werx.controllers.swingcontroller.processors;

import javax.swing.JFrame;

import org.werx.controllers.swingcontroller.signals.SetCursorSignal;

public class SetCursorProcessor  {

	private final JFrame frame;

	public SetCursorProcessor(JFrame frame)
	{
		this.frame=frame;
	}
	
    public void doProcess(SetCursorSignal signal)
    {
        frame.setCursor(signal.cursor);
    }
}