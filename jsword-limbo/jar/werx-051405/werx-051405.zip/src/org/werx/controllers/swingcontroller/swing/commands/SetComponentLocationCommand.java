package org.werx.controllers.swingcontroller.swing.commands;

import java.awt.Component;

import org.werx.framework.commons.commands.ICommand;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */

public class SetComponentLocationCommand implements ICommand
{

    private Component itemToLocate;
    private String xLocation;
    private String yLocation;

    /**
     * Creates a new SetComponentLocationCommand object.
     *
     * @param toLocate The component to be located on the screen
     * @param theLocation The String value of the location defined by class constants
     */
    public SetComponentLocationCommand(Component toLocate, String horizontal, String vertical)
    {
        itemToLocate = toLocate;
        yLocation = vertical;
        xLocation = horizontal;
    }

    /**
     * Calculate the location of the upper left x,y based on specified location.
     */
    public void execute()
    {

        int x = 0;
        int y = 0;

        //xCalcs...
        if (xLocation.equals(ComponentLocationCalculator.CENTER))
        {
            x = calculateCenteredXLocation();
        }

        //yCalcs...
        if (yLocation.equals(ComponentLocationCalculator.CENTER))
        {
            y = calculateCenteredYLocation();
        }
        else if (yLocation.equals(ComponentLocationCalculator.CENTER))
        {
            y = calculateBottomYLocation();
        }


        //set the location...
        
        itemToLocate.setLocation(x, y);

        ////System.out.println(x+","+y);
    }


    private int calculateCenteredXLocation()
    {
        return ComponentLocationCalculator.calculateCenteredXLocation(itemToLocate.getParent().getSize(),itemToLocate);
    }

    private int calculateCenteredYLocation()
    {
        return ComponentLocationCalculator.calculateCenteredYLocation(itemToLocate.getParent().getSize(),itemToLocate);
    }


    private int calculateBottomYLocation()
    {
        return ComponentLocationCalculator.calculateBottomYLocation(itemToLocate.getParent().getSize(),itemToLocate);
       
    }
}