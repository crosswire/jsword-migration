/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Nathan Slippen
 * @created on Apr 29, 2005 
 * @version Version2.1
 *   
 */


package org.werx.controllers.filecontroller.file.signals;


/**
 * @author Nathan
 *
 */



public class FileReadSignal implements IFileSignal {

	private static String FILE_NAME = "fileName";
	String fileName;


	/**
	 * Creates a new FileReadSignal object.
	 *
	 *@param  fileName      Description of the Parameter
	 */
	public FileReadSignal(String fileName) {
		this.fileName = fileName;

	}


	/**
	 *  Gets the fileName attribute of the FileReadSignal object
	 *
	 *@return    The fileName value
	 */
	public String getFileName() {
		return fileName;
	}
	

	
    public static void main(String[] args) {
        
    }
    
}

