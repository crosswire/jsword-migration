/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.signals;

import java.awt.Window;

/**
 * @author Bradlee
 *

 */
public class WindowSizeSignal implements ISwingSignal{

    public final Window wToSize;
    public final int inset;
    
    public WindowSizeSignal(Window wToSize, int inset)
    {
        this.wToSize=wToSize;
        this.inset=inset;
    }
    
}
