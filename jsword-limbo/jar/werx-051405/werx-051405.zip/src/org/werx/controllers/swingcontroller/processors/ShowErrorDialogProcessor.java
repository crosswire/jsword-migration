package org.werx.controllers.swingcontroller.processors;

import java.awt.Cursor;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.werx.controllers.swingcontroller.swing.desktop.signals.ShowErrorSignal;

public class ShowErrorDialogProcessor  {

	private final JFrame frame;

	public ShowErrorDialogProcessor(JFrame frame)
	{
		this.frame=frame;
	}
	
    public void doProcess(ShowErrorSignal signal)
    {
        JOptionPane.showMessageDialog(frame, signal.errorMessage, signal.title, JOptionPane.ERROR_MESSAGE);
        frame.setCursor(Cursor.DEFAULT_CURSOR);
    }
}