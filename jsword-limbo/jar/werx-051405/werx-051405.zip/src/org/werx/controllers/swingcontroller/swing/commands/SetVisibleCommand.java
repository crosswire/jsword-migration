package org.werx.controllers.swingcontroller.swing.commands;

import java.awt.Component;
import java.awt.Window;

import org.werx.framework.commons.commands.ICommand;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */

public class SetVisibleCommand implements ICommand
{
    Component init;

    /**
     * Creates a new SetVisibleCommand object.
     *
     * @param toInitialize The object to set visible
     */
    public SetVisibleCommand(Component toInitialize)
    {
        init = toInitialize;
    }

    /**
     * The object is set visible and then packed if necessary.
     */
    public void execute()
    {
        if (init instanceof Window)
        {
            ((Window) init).pack();
        }
        init.setVisible(true);
    }
}