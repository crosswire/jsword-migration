/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.imagecontroller.signals;

import java.util.HashMap;

import javax.swing.ImageIcon;

import org.werx.framework.bus.signals.BusSignal;

/**
 * @author Bradlee
 *
 */
public class ReturnImageIconsSignal extends BusSignal {
    
    private final HashMap imgs;
    public ReturnImageIconsSignal(BusSignal requestor, HashMap imgs)
    {
        super(requestor);
        this.imgs=imgs;
    }

    

    
    public ImageIcon getImageIcon(String name)
    {
        return (ImageIcon) imgs.get(name);
    }

}
