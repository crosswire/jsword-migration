package org.werx.controllers.swingcontroller.swing.commands;

import java.awt.Component;
import java.awt.Dimension;

/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */

public class ComponentLocationCalculator
{
    public static final String CENTER = "center";
    public static final String BOTTOM = "bottom";
    private Component itemToLocate;


    public static int calculateCenteredXLocation(Dimension parentSize, Component itemToLocate)
    {
        return (parentSize.width - itemToLocate.getWidth()) / 2;
    }

    public static int calculateCenteredYLocation(Dimension parentSize, Component itemToLocate)
    {
        return (parentSize.height - itemToLocate.getHeight()) / 2;
    }


    public static int calculateBottomYLocation(Dimension parentSize, Component itemToLocate)
    {
        return parentSize.height - itemToLocate.getHeight();
    }
}