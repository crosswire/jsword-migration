/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.processors;

import java.awt.Dimension;
import java.awt.Toolkit;

import org.werx.controllers.swingcontroller.signals.WindowSizeSignal;

/**
 * @author Bradlee
 *
 */
public class WindowSizeProcessor {
    

    public void doProcess(WindowSizeSignal signal)
    {

      
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        
		signal.wToSize.setBounds(signal.inset, signal.inset, screenSize.width - (signal.inset * 2), screenSize.height - (signal.inset * 2));
		signal.wToSize.validate();
    }
}
