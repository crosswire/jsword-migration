/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Nathan Slippen
 * @created on Apr 29, 2005
 * @version Version2.1
 *   
 */
package org.werx.controllers.filecontroller.file.signals;



/**
 * @author Nathan S.
 *
 */

public class OpenFileSignal	 implements IFileSignal {

public final static String PROPERTIES = "org.werx.framework.file.filestate.PropertiesFileState";
private String fileName;
private String fileType;



	/**
	 * Creates a new instance of OpenFileSignal
	 *
	 *@param  fileName   the name of the file to open
	 *@param  fileType   Description of the Parameter
	 *@param  requestor  Description of the Parameter
	 */
	public OpenFileSignal(String fileName, String fileType) {
	
		this.fileName = fileName;
		this.fileType = fileType;

	}
	
	
	/**
	 * Returns the name of the file that will be opened for writing.
	 *
	 *@return    the name of the file that the signal is requesting to open.
	 */
	public String getFileName() {
		return fileName;
	}
	
	
	/**
	 *  Gets the fileType attribute of the OpenFileSignal object
	 *
	 *@return    The fileType value
	 */
	public String getFileType() {
		return fileType;
	}




}

