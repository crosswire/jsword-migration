package org.werx.controllers.swingcontroller.swing.desktop.signals;

import org.werx.controllers.swingcontroller.signals.ISwingSignal;
import org.werx.framework.bus.signals.BusSignal;

/**
 * WERX - Java Swing RAD Framework
 * Copyright 2002 Bradlee Johnson
 * Released under LGPL license
 *
 * @version 0.1
 * @author Bradlee Johnson
 */

public class ShowErrorSignal extends BusSignal implements ISwingSignal
{
    
    public final String title;
    public final String errorMessage;
    public final Exception e;


    public ShowErrorSignal(String title, String errorMessage, Exception e)
    {
       this.title=title;
       this.errorMessage=errorMessage;
       this.e=e;
    }


    
    
}