/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.commands;

import org.werx.framework.commons.commands.ICommand;

/**
 * @author Bradlee
 *
 *
 */
public class ConsoleOutCommand implements ICommand {

    String toPrint;
    
    public ConsoleOutCommand(String toPrint)
    {
        this.toPrint=toPrint;
    }
    /* 
     * 
     */
    public void execute() {
        System.out.println(toPrint);
    }

}
