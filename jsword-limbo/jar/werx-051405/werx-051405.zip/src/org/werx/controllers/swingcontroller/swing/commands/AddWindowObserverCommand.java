/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.commands;

import java.awt.Window;

import org.werx.controllers.swingcontroller.swing.observers.WindowObserver;
import org.werx.framework.commons.commands.ICommand;

/**
 * @author Bradlee
 *
 */
public class AddWindowObserverCommand implements ICommand {

    String fireOn;
    ICommand c;
    Window w;
    
    
    public AddWindowObserverCommand(String fireOn, ICommand c, Window w)
    {
        this.fireOn=fireOn;
        this.w=w;
        this.c=c;
    }

    public void execute() {
       
        WindowObserver wo=new WindowObserver(w);
        wo.setCommand(fireOn,c);
    

    }

}
