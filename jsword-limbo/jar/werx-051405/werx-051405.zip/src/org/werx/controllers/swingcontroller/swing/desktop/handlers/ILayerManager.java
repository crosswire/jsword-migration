package org.werx.controllers.swingcontroller.swing.desktop.handlers;
import javax.swing.JInternalFrame;

/**
 * WERX - Java Swing RAD framework
 * Copyright 2002 Bradlee Johnson
 * Released under LGPL license
 *
 *@author     Bradlee Johnson
 *@created    May 20, 2003
 *@version    0.1
 */

public interface ILayerManager
{


	/**
	 *  Description of the Method
	 *
	 *@param  toAdd  Description of the Parameter
	 */
	public void add(JInternalFrame toAdd);


	/**
	 *  Description of the Method
	 *
	 *@param  toRemove  Description of the Parameter
	 */
	public void remove(JInternalFrame toRemove);


}
