/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Nathan Slippen
 * @created on Apr 29, 2005 
 * @version Version2.1
 *   
 */


package org.werx.controllers.filecontroller.file.signals;




/*
 * @author Nathan
 */

public class CloseFileSignal implements IFileSignal {
	private String fileName;


	/**
	 * Creates a new instance of CloseFileSignal
	 *
	 *@param  theRequestor  Description of the Parameter
	 *@param  fileName      Description of the Parameter
	 */
	public CloseFileSignal(String fileName) {
		this.fileName = fileName;
	}


	/**
	 *  Gets the fileName attribute of the CloseFileSignal object
	 *
	 *@return    The fileName value
	 */
	public String getFileName() {
		return fileName;
	}

	
    public static void main(String[] args) {
    }
}


