/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.imagecontroller.signals;

import org.werx.framework.bus.signals.BusSignal;

/**
 * @author Bradlee
 *
 */
public class GetImageIconsSignal extends BusSignal {
    
    public final String[] imgs;
    public GetImageIconsSignal(Object requestor, String[] imgs)
    {
        super(requestor);
        this.imgs=imgs;
    }
    
    public GetImageIconsSignal(Object requestor, String img)
    {
        super(requestor);
        this.imgs=new String[]{img};
    }
    

}
