/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.desktop.decorators;

import javax.swing.JComponent;

import org.werx.controllers.swingcontroller.swing.desktop.signals.DesktopSizeSignal;
import org.werx.framework.bus.ReflectionBus;

/**
 * @author Bradlee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RevalidateVisibleDecorator {


    	JComponent toKeepVisible;


    	/**
    	 *Constructor for the StayVisibleLocationDecorator object
    	 *
    	 *@param  comp  Description of the Parameter
    	 */
    	public RevalidateVisibleDecorator(JComponent comp)
    	{
    		toKeepVisible = comp;
    		ReflectionBus.plug(this);
    	}


    	/**
    	 * channel(DesktopSizeSignal method for adding a JIF
    	 * to the current desktop
    	 *
    	 *@param  theSignal  The signal with the dimension
    	 */
    	public void channel(DesktopSizeSignal  theSignal)
    	{
    		DesktopSizeSignal signal = (DesktopSizeSignal) theSignal;

    		if (toKeepVisible.getX() < 0)
    			toKeepVisible.setLocation(0, toKeepVisible.getY());
    		if (toKeepVisible.getY() < 0)
    			toKeepVisible.setLocation(toKeepVisible.getX(), 0);

    		if (toKeepVisible.getX() > signal.getDesktopSize().getWidth())
    			toKeepVisible.setLocation((int) signal.getDesktopSize().getWidth() - toKeepVisible.getWidth(), toKeepVisible.getY());

    		if (toKeepVisible.getY() > signal.getDesktopSize().getHeight())
    			toKeepVisible.setLocation(toKeepVisible.getX(), (int) signal.getDesktopSize().getHeight() - toKeepVisible.getHeight());

    	}

    }


