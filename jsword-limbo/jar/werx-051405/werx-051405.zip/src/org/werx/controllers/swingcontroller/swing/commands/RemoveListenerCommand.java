/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.swing.commands;

import java.awt.Window;
import java.awt.event.WindowListener;

import org.werx.framework.commons.commands.ICommand;

/**
 * @author Bradlee
 *
 */
public class RemoveListenerCommand implements ICommand {

    WindowListener listener;
    Window window;
    public RemoveListenerCommand(WindowListener listener, Window window)
    {
        this.listener=listener;
        this.window=window;
    }
    //Remove the listener and then null handles to
    //aid in gc.
    public void execute() {
        window.removeWindowListener(listener);
        listener=null;
        window=null;
        System.gc();
    }

}
