/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.controller;

import java.lang.reflect.Method;
import java.util.HashMap;

import javax.swing.SwingUtilities;

import org.werx.controllers.swingcontroller.signals.RemoveProxySignal;
import org.werx.controllers.swingcontroller.swing.desktop.handlers.IRemoveable;
import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.processors.MethodInstancePair;

/**
 * @author Bradlee
 *

 */
public class SwingProxy {

    private final String methodPrefix;
    private HashMap map = new HashMap();
    Object proxiedObject;
    public SwingProxy(Object proxiedObject, String methodPrefix)
    {
        this.proxiedObject=proxiedObject;
		this.methodPrefix=methodPrefix;
        Class aComponentClass = (Class) proxiedObject.getClass();
        Method[] aComponentMethods = aComponentClass.getMethods();

        try {

            for (int i = 0; i < aComponentMethods.length; i++) {
                //Look at each method and put them in the appropriate
                //hash table.
                String methodName = aComponentMethods[i].getName();

                if (methodName.startsWith(methodPrefix)) {
                    Class[] c = aComponentMethods[i].getParameterTypes();
                    //This is a valid channel name so we are now going to
                    //register it.
                   map.put(c[0].getName(),
                            new MethodInstancePair(aComponentMethods[i],
                                    proxiedObject));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        ReflectionBus.plug(this);
    }
  
    public synchronized void removeProxy()
    {
        
        if(proxiedObject instanceof IRemoveable)
            ((IRemoveable) proxiedObject).remove();
        ReflectionBus.unplug(this);
        map.clear();
        this.proxiedObject=null;
        map=null;
    }
    
    public void channel(RemoveProxySignal signal)
    {

        if(signal.proxiedObject==this.proxiedObject)
        {
           removeProxy();
        }
    }
   
    public void channel(Object signal)
    {
   
        MethodInstancePair pair = (MethodInstancePair) map.get(signal.getClass().getName());
        if(pair!=null)
        {
            SwingUtilities.invokeLater(new SwingMIPRunnable(pair,signal));
        }
    }
}
