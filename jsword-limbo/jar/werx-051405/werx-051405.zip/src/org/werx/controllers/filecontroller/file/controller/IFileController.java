/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Nathan Slippen
 * @created on Apr 30, 2005 , 2005
 * @version Version2.1
 *   
 */


package org.werx.controllers.filecontroller.file.controller;
/*
 * @author Nathan
 */

public interface IFileController {

	/**  Description of the Field */
	public final static String CSV = "New String";
}






