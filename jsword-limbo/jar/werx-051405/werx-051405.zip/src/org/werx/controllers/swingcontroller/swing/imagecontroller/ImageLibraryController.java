package org.werx.controllers.swingcontroller.swing.imagecontroller;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import javax.swing.ImageIcon;

import org.werx.controllers.swingcontroller.swing.imagecontroller.signals.GetImageIconsSignal;
import org.werx.controllers.swingcontroller.swing.imagecontroller.signals.ReturnImageIconsSignal;
import org.werx.framework.bus.ReflectionBus;

/**
 * WERX - Java Swing RAD Framework Copyright 2002 Bradlee Johnson Released under
 * LGPL license
 * 
 * @author Bradlee Johnson
 * @created 2005
 * @version 2.1
 */

public class ImageLibraryController {

    private HashMap imageMap = new HashMap();

    private String libraryName = "";

    public ImageLibraryController(String libName) {
        libraryName = "jar:file:./" + libName + "!/";
        ReflectionBus.plug(this);
    }

    /**
     * Gets the imageIcon attribute of the ImageLibraryController class
     * 
     * @param anImageName
     *            Description of the Parameter
     * @return The imageIcon value
     */
    public void channel(GetImageIconsSignal signal) {

        ReflectionBus.broadcast(new ReturnImageIconsSignal(signal,
                getImage(signal.imgs)));
    }

    private HashMap getImage(String[] names) {
        HashMap imgs = new HashMap();
        for (int i = 0; i < names.length; i++) {
            Object img = imageMap.get(names[i]);
            if (img == null) {
                try {
                    URL url = new URL(libraryName + names[i]);

                    img = new ImageIcon(url);
                    imageMap.put(names[i], img);
                    
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }
            
            imgs.put(names[i], img);
        }
        return imgs;

    }

}

