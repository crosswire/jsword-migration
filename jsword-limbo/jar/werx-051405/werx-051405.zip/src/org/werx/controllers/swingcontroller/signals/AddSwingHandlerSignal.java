/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *  * 
 */
package org.werx.controllers.swingcontroller.signals;

import javax.swing.JComponent;

/**
 * @author Bradlee
 *
 */
public class AddSwingHandlerSignal  {

    public final Object handler;
	public final JComponent component;
 
    public AddSwingHandlerSignal(Object handler, JComponent component)
    {
        this.handler=handler;
		this.component=component;
		
    }
    
}
