package org.werx.controllers.swingcontroller.swing.desktop.handlers;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

/**
 * WERX - Java Swing RAD framework
 * Copyright 2002 Bradlee Johnson
 * Released under LGPL license
 *
 *@author     Bradlee Johnson
 *@created    May 20, 2003
 *@version    0.1
 */

public class LayerManager implements ILayerManager
{
	//----------------------------------------------------------------------
	JDesktopPane desktop;

	private int xOffset = 20;
	private int yOffset = 20;
	private int currentXOffset = 20;
	private int currentYOffset = 20;
	private int maxYOffset = 400;
	private int minYOffset = 20;
	private Integer myLayer;


	/**
	 * Creates a new Desktop object.
	 *
	 *@param  theDesktop  The desktopPane to use.
	 *@param  aLayer      Description of the Parameter
	 */
	public LayerManager(JDesktopPane theDesktop, Integer aLayer)
	{
		desktop = theDesktop;
		myLayer = aLayer;

	}


	/**
	 *  Adds a feature to the JInternalFrameToTop attribute of the LayerManager object
	 *
	 *@param  aJInternalFrame  The feature to be added to the JInternalFrameToTop attribute
	 */
	private void addJInternalFrameToTop(JInternalFrame aJInternalFrame)
	{
		desktop.add(aJInternalFrame, myLayer);
		desktop.moveToFront(aJInternalFrame);
	}


	/**
	 *  Sets the jInternalFrameOffset attribute of the LayerManager object
	 *
	 *@param  aJInternalFrame  The new jInternalFrameOffset value
	 */
	private void setJInternalFrameOffset(JInternalFrame aJInternalFrame)
	{
		incrementOffset();
		aJInternalFrame.setLocation(currentXOffset, currentYOffset);

	}


	/**
     *  Description of the Method
     *
     *@param  toAdd  Description of the Parameter
     */
    public void add(JInternalFrame toAdd)
    {
        
    	addJInternalFrameToTop(toAdd);
    	setJInternalFrameOffset(toAdd);
    	toAdd.pack();
    	toAdd.show();
    
    	desktop.revalidate();
    	desktop.repaint();
    }


	/**
	 *  Description of the Method
	 *
	 *@param  toRemove  Description of the Parameter
	 */
	public void remove(JInternalFrame toRemove)
	{
		if (toRemove.getX() == currentXOffset && toRemove.getY() == currentYOffset)
			decrementOffset();
		desktop.remove(toRemove);
		toRemove.dispose();
		desktop.repaint();
	}


	/**  Description of the Method */
	private void decrementOffset()
	{
		currentXOffset = currentXOffset - xOffset;
		currentYOffset = currentYOffset - yOffset;

		if (currentYOffset < minYOffset)
		{
			currentYOffset = 20;
			currentXOffset = 20;
		}
	}


	/**  Description of the Method */
	private void incrementOffset()
	{
		currentXOffset = currentXOffset + xOffset;
		currentYOffset = currentYOffset + yOffset;

		if (currentYOffset > maxYOffset)
		{
			currentXOffset = 20;
			currentYOffset = 20;
		}

	}
}
