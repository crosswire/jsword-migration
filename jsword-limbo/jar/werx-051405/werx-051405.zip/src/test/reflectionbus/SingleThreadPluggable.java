/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.reflectionbus;

import java.util.Calendar;
import java.util.Date;
import java.util.logging.Logger;

import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.workerthread.signals.ProcessRunnableSignal;

/**
 * 
 */
public class SingleThreadPluggable implements Runnable {

	int counter = 0;

	int numberOfTests = 10000;

	long millis;

	Logger logger;
	
	boolean isSingle;


	public SingleThreadPluggable(Logger logger, boolean isSingle) {
		this.logger = logger;
		this.isSingle=isSingle;
		logger.info("Preparing for Single Thread Performance Test...");
		ReflectionBus.plug(this);
		millis = new Date().getTime();
		ReflectionBus.broadcast(new ProcessRunnableSignal(this, this));
	}

	public void channel(ProcessRunnableSignal signal) {
		counter++;

		if (counter < numberOfTests) {
			ReflectionBus.broadcast(new ProcessRunnableSignal(this, this));
		} else {
			millis = Calendar.getInstance().getTimeInMillis() - millis;
			StringBuffer buf = new StringBuffer();
			buf.append("Total Test Time: " + millis + " milliseconds\n");
			buf.append("Total Message Sent: " + numberOfTests + "\n");
			int perMillis=(int)( numberOfTests / millis);
			buf.append("Messages per millisecond: "+  perMillis + "\n");
			buf.append("Messages per second: "+  perMillis*1000 + "\n");
			buf.append("******************\n");
			buf.append("Test conditions: \n");
			buf.append("Tests are single message with one message listeners.\n");
			buf.append("Tests are run on same input/output thread\n");
			buf.append("******************\n");
			logger.info(buf.toString());
			ReflectionBus.unplug(this);
			
			System.out.println("Single Thread Test Finished.");
			if(isSingle)
				System.exit(0);
			
		}
	}

	public void run() {

	}

}