/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.reflectionbus;

/**
 * 
 */

import java.util.Date;
import java.util.Random;
import java.util.logging.Logger;

import org.werx.framework.bus.ReflectionBus;

public class MultiThreadChannelTest {

	static Logger logger = Logger.getLogger(MultiThreadChannelTest.class.getName());

	public MultiThreadChannelTest() {
		logger.info("MULTITRHEADCHANNEL TEST\n###################################################");
		logger.info("Starting MultiThreadChannelTest...");

		logger.info("Plugging in new MultiChannelThreaded...");
		
		ReflectionBus.plug(new MultiChannelThreaded(logger));

	}


}

class MultiChannelThreaded {

	Random r = new Random();

	Date d = new Date();

	static int numObj = 0;
	
	static int numThreads=0;

	Logger logger;

	public MultiChannelThreaded(Logger logger) {
		this.logger = logger;
		ReflectionBus.plug(this);
		logger.info("Sending first signal...");
		r.setSeed(d.getTime());
		numObj++;
		ReflectionBus.broadcast(new FirstChannelSignal(this));

	}

	public void channel(FirstChannelSignal signal) {

		if (signal.isMyAddress(this)) {
			logger.info("Received first channel signal...");

			ReflectionBus.broadcast(new SecondChannelSignal(this));
		}
	}

	public void channel(SecondChannelSignal signal) {
		if (signal.isMyAddress(this)) {
			logger.info("Second channel signal");
			if (r.nextBoolean() == true) {
				logger.info("Broadcast on new thread");
				final ThirdChannelSignal tcs=new ThirdChannelSignal(this);
				numThreads++;
				new Thread(new Runnable() {
					public void run() {
						ReflectionBus.broadcast(tcs);
					}
				}).start();
			} else {
				logger.info("Broadcast on current thread");
				ReflectionBus.broadcast(new ThirdChannelSignal(this));
			}
			ReflectionBus.plug(new MultiChannelThreaded(logger));

			if (r.nextBoolean() == true) {
				logger.info("Plug in on new thread");
				numThreads++;
				//System.out.println("New thread starting: " + numThreads);
				new Thread(new Runnable() {
					public void run() {
						ReflectionBus.plug(new MultiChannelThreaded(logger));
					}
				}).start();
			} else {
				logger.info("Plug in on current thread");
				ReflectionBus.plug(new MultiChannelThreaded(logger));
			}

		}

	}

	public void channel(ThirdChannelSignal signal) {
		
		if (signal.isMyAddress(this) ) {
			ReflectionBus.unplug(this);
			logger.info("Third channel signal");
			//System.out.println("Number of objects: " + numObj);
			logger.info("Current number of objects: " + numObj);
			if (numObj > 150) {
				logger.info("Test finished");
				System.out.println(" Finished MultiThreadChannel Test");
				//ReflectionBus.broadcast(new StopSignal());

				System.exit(0);
			}
		}
	}

}