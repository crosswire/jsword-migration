/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.reflectionbus;

/**
 *  
 */

import java.util.logging.Logger;

import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.spinlock.signals.StopProcessSignal;
import org.werx.framework.workerthread.WorkerThreadController;
import org.werx.framework.workerthread.signals.ProcessRunnableSignal;
import org.werx.framework.workerthread.signals.ReturnProcessRunnableSignal;

public class ThreadTest {

    static Logger logger = Logger.getLogger(ThreadTest.class.getName());

    boolean isSingle;

    Object keepAlive = new Object();

    private static WorkerThreadController asSingleton;

    String threadName = "Thread Test Worker Thread";

    public ThreadTest() {

        logger.info("THREAD TEST\n###################################################");
        logger.info("Pluging in ThreadTest...");

        ReflectionBus.plug(this);

        TestRunnable runTest = new TestRunnable();
        ReflectionBus.broadcast(new ProcessRunnableSignal(this, runTest));

    }

    public void channel(ReturnProcessRunnableSignal signal) {
        System.out.println("Signal: " + signal);
        ReflectionBus.unplug(this);
        ReflectionBus.broadcast(new StopProcessSignal(this, threadName));
        ReflectionBus.resetbus();
        System.out.println("Finished Thread Test");
        if (isSingle) {
            logger.info(signal.getRunnable().toString());
            logger.info("Test finished");
            System.exit(0);
        }

    }

    private void fireSignal() {

    }

    private class TestRunnable implements Runnable {
        int numberOfCycles;

        String nameOfWorkerThread;

        int numberOfTests = 10;

        public void run() {
            for (int i = 0; i < numberOfTests; i++) {
                numberOfCycles = i;
            }
            nameOfWorkerThread = Thread.currentThread().getName();
        }

        public String toString() {
            return "Worker thread ran " + numberOfCycles;
        }

        public int getCycles() {
            return numberOfCycles;
        }

        public String getWorkerThreadName() {
            return nameOfWorkerThread;
        }
    }



}