/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.reflectionbus;

/**
 * 
 */

import java.util.logging.Logger;

import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.bus.signals.GenericSignal;
import org.werx.framework.springutils.Bootstrap;

import test.clientJVM.BusMessageOutputPlugin;
import test.clientJVM.MemoryOutput;
import test.clientJVM.TestCommunicationInput;

public class PlugUnplugLeakTest implements Runnable {

	static Logger logger = Logger.getLogger(PlugUnplugLeakTest.class.getName());

	public void run() {
	    new Bootstrap("specifications/standardconfig/busconfig.xml");
		logger
				.info("PLUGANDUNPLUG TEST\n###################################################");
		logger.info("Starting Plug & Unplug Test...");

		logger.info("Starting Memory Output");
		new MemoryOutput(logger);
		//No need to see messages. Just eat
		//up test jig memory.
		logger.info("BusSignal=DisableDisplay");
		logger.info("Text=DisableDisplay");

		logger.info("Adding test communication handler...");
		ReflectionBus.plug(new BusMessageOutputPlugin(logger));
		logger.info("Adding test communication handler...");
		new TestCommunicationInput(logger);
		
		logger.info("Plugging in new HandOverFistPluggable...");
		ReflectionBus.plug(new HandOverFistPluggable(logger));
		logger.info("Sending broadcast signal...");
		ReflectionBus.broadcast(new GenericSignal(this, this));

	}

	public static void main(String[] args) {
		new Thread(new PlugUnplugLeakTest()).start();
	}
}
//Simply chains multiple plug and unplug events using
//the start signal as the trigger. This is intended to
//run repeatedly to ensure that memory leaks are not present
//in the channel or chanel map.

class HandOverFistPluggable {
	Logger logger;

	public HandOverFistPluggable(Logger logger) {
		this.logger = logger;
	}

	public void channel(GenericSignal signal) {
		logger.info("Unplugging old and adding new...");
		ReflectionBus.plug(new HandOverFistPluggable(logger));
		ReflectionBus.unplug(this);
		ReflectionBus.broadcast(new GenericSignal(this, this));
	}

}