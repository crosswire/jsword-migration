/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.reflectionbus;

import java.util.Calendar;
import java.util.logging.Logger;

import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.spinlock.signals.StopProcessSignal;
import org.werx.framework.workerthread.signals.ProcessRunnableSignal;
import org.werx.framework.workerthread.signals.ReturnProcessRunnableSignal;

/**
 * 
 */
public class DualThreadPluggable implements Runnable {

	int counter = 0;

	int numberOfTests = 10000;

	long millis;

	Logger logger;
	
	private static int instanceCount=0;

	String threadName = "Dual Thread Pluggable Worker Thread";

	public DualThreadPluggable(Logger logger) {
		this.logger = logger;
		logger.info("Preparing for Test with Return from Worker Thread...");

		

		millis = Calendar.getInstance().getTimeInMillis();
		logger.info("Instances="+ ++instanceCount);
		//System.out.println("Instances: " + instanceCount);
		ReflectionBus.plug(this);
		ReflectionBus.broadcast(new ProcessRunnableSignal(this, this));
	}

	public synchronized void channel(ReturnProcessRunnableSignal signal) {

		counter++;

		if (counter < numberOfTests) {
			ReflectionBus.broadcast(new ProcessRunnableSignal(this, this));
		} else {
		   
			logger.info("Current Count " + counter);
			millis = Calendar.getInstance().getTimeInMillis() - millis;
			StringBuffer buf = new StringBuffer();
			buf.append("Total Test Time: " + millis + " milliseconds\n");
			buf.append("Total Message Sent: " + numberOfTests + "\n");
			long perMillis = (long) (numberOfTests / millis);
			buf.append("Messages per millisecond: " + perMillis + "\n");
			buf.append("Messages per second: " + perMillis * 1000 + "\n");
			buf.append("******************\n");
			buf.append("Test conditions: \n");
			buf.append("Tests are two messages with one message listener.\n");
			buf.append("Tests are run with one input and one worker thread\n");
			buf.append("******************\n");

			logger.info(buf.toString());

			logger.info("Test finished");
			 
			logger.info("Sending stop process signal");
			ReflectionBus.broadcast(new StopProcessSignal(this, threadName));
			ReflectionBus.unplug(this);
		    
			System.out.println("Finished DualThreadPluggable Test.");

			
		}
	}

	public void run() {
		//This does nothing and used simply for
		//the benefit of the test.

	}

}

