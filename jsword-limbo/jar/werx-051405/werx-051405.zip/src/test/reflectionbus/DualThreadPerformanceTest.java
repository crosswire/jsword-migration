/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.reflectionbus;

/**
 * 
 */



import java.util.logging.Logger;

import org.werx.framework.bus.ReflectionBus;
import org.werx.framework.commons.spinlock.signals.NotifyStopProcessSignal;



public class DualThreadPerformanceTest  {

	static Logger logger = Logger.getLogger(DualThreadPerformanceTest.class.getName());
	
	public DualThreadPerformanceTest()
	{
	    
		logger.info("PERFORMANCE TEST\n###################################################");
		logger.info("Pluging in Performance Test...");
		
		
		ReflectionBus.plug(this);
		new DualThreadPluggable(logger);
		
		
		

	}
	
	//Notify stop is sent when the lock exits indicating that
	//the thread is now done. When multiple threads or
	//controllers are used one must check the name.
	public void channel(NotifyStopProcessSignal stopSignal)
	{
	   		
		ReflectionBus.unplug(this);
		System.exit(0);
		
	}



}

