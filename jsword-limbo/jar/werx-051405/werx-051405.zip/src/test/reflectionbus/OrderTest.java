/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.reflectionbus;

/**
 *  
 */

import java.util.logging.Logger;

import org.werx.framework.bus.ReflectionBus;

public class OrderTest {

    static Logger logger = Logger.getLogger(OrderTest.class.getName());

    int total=5;
    int signalCount=0;
    public OrderTest()
    {

        logger.info("THREAD TEST\n###################################################");
        logger.info("Pluging in OrderTest...");
        System.out.println("Standard LIFO broadcast");

        for (int i = 0; i < total; i++)
            ReflectionBus.plug(new OrderPluggable(i));
        
        ReflectionBus.plug(this);
        ReflectionBus.broadcast(new GetOrderSignal());
        
    }

    private class GetOrderSignal {

    }
    
    private class ReturnOrderSignal
    {
        int order;
        public ReturnOrderSignal(int i)
        {
            this.order=i;
        }
        
        public void printOrder()
        {
            System.out.println("Returned Order: " + order);
        }
        
        public int getOrder()
        {
            return order;
        }
    }
    
    public void channel(ReturnOrderSignal signal)
    {
        signal.printOrder();
        signalCount++;
        System.out.println("Signal Count: "+ signalCount);
        if(total==signalCount)
        {
            System.out.println("Order Test Finished");
            System.exit(0);
        }
    }

    private class OrderPluggable {
        int myOrder;

        public OrderPluggable(int order) {
            this.myOrder = order;
        }

        public void channel(GetOrderSignal signal) {
            ReflectionBus.broadcast(new ReturnOrderSignal(myOrder));
        }

        public int getOrder() {
            return myOrder;
        }
    }


}