/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.reflectionbus;

/**
 * 
 */

import java.util.logging.Logger;

import org.werx.framework.bus.ReflectionBus;

public class SingleThreadPerformanceTest  {

	static Logger logger = Logger.getLogger(SingleThreadPerformanceTest.class.getName());

	public SingleThreadPerformanceTest() {
		logger.info("PERFORMANCE TEST\n###################################################");
		logger.info("Pluging in Performance Test...");
		
		ReflectionBus.plug(this);

		ReflectionBus.plug(new SingleThreadPluggable(logger,true));
		

	}


}

