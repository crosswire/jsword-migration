/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.reflectionbus;

import org.werx.framework.bus.signals.BusSignal;

/**
 * @author Bradlee
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class FirstChannelSignal extends BusSignal {

	public FirstChannelSignal(Object sender) {
		super(sender);
	}

}