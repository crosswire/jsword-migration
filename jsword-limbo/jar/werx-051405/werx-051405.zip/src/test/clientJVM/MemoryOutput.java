/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.clientJVM;
import java.util.logging.Logger;


/**
 * 
 */

//Framework specific imports
/**
 * Is Alive Heartbeat
 */
public class MemoryOutput implements Runnable {

	private Logger logger;

	public MemoryOutput(Logger logger) {
		this.logger = logger;
		new Thread(this, "Memory Output").start();
	}

	public void run() {
		logger.info("MaxMemory=" + Runtime.getRuntime().maxMemory());

		while (true) {

			try {

				Thread.sleep(2000);
				logger
						.info("TotalMemory="
								+ Runtime.getRuntime().totalMemory());
				logger.info("FreeMemory=" + Runtime.getRuntime().freeMemory());

			} catch (Exception e) {
				e.printStackTrace();
				System.exit(99);
			}

		}

	}

}