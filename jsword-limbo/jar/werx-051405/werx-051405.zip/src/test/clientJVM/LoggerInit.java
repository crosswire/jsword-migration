/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.clientJVM;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


/**
 * 
 *  
 */
public class LoggerInit {

	String name;

	public LoggerInit(String name) {
		this.name = name;
	}

	public Logger getLogger() {

		Logger logger = Logger.getAnonymousLogger();
		logger.setUseParentHandlers(false);
		//Let these stack traces print. Since this is
		//setting up the logger there is nothing to log to
		//and missing this information would be bad.
		try {
			FileHandler handler = new FileHandler(name + ".log");
			handler.setFormatter(new SimpleFormatter());
			logger.addHandler(handler);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return logger;

	}

}