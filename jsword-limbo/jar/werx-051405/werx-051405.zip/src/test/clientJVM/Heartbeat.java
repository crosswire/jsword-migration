/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.clientJVM;
import java.util.Calendar;
import java.util.logging.Logger;


/**
 * 
 *  
 */

//Framework specific imports
/**
 * Is Alive Heartbeat
 */
public class Heartbeat implements Runnable {

	private Logger logger;

	public Heartbeat(Logger logger) {
		this.logger = logger;
		new Thread(this, "Heartbeat").start();
	}

	public void run() {
		while (true) {

			try {

				Thread.sleep(1000);
				logger.info("Heartbeat at: "
						+ Calendar.getInstance().getTimeInMillis());
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(99);
			}

		}

	}

}