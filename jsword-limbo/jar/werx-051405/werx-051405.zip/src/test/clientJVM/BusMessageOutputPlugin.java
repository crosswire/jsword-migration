/**
 * WERX2 - Java Lightweight Messaging Bus
 * Copyright 2005 Bradlee Johnson
 * Released under LGPL license
 * @author Bradlee Johnson
 * @created 2004
 * @version Version2.1
 *   
 */
package test.clientJVM;

//Framework specific imports
import java.util.logging.Logger;

import org.werx.framework.bus.signals.BusSignal;

/**
 * Communications plug in for sending messages to and receiving messages from
 * the TestJig
 */
public class BusMessageOutputPlugin {

	Logger logger;

	public BusMessageOutputPlugin(Logger logger) {
		this.logger = logger;
	}

	/**
	 * ChannelProxy to recive messages on the ReflectionBus
	 * 
	 * @param theSignal
	 *            Received bus signal
	 */
	public void channel(BusSignal theSignal) {

		logger.info(theSignal.toString());

	}
}